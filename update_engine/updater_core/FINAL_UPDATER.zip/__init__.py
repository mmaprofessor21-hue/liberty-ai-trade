# updater/updates/__init__.py
import sys
sys.dont_write_bytecode = True