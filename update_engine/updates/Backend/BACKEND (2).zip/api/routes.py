import sys; sys.dont_write_bytecode = True
from fastapi import APIRouter

api_blueprint = APIRouter()

@api_blueprint.get("/status")
def status():
    return {"message": "Backend API is working!"}

@api_blueprint.post("/telegram")
def telegram_webhook():
    return {"message": "Telegram webhook received"}
# TIMESTAMP: 2025-05-04 20:26:50