import sys; sys.dont_write_bytecode = True
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import api_blueprint

app = FastAPI()

# Allow frontend requests during development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def read_root():
    return {"message": "Liberty AI Trade Backend Running"}

# Register API endpoints under /api
app.include_router(api_blueprint, prefix="/api")
# TIMESTAMP: 2025-05-04 20:30:05