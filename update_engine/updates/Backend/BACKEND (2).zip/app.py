# TIMESTAMP: 2025-05-04 17:12:12
from fastapi import FastAPI
from routes import router

app = FastAPI()
app.include_router(router)