# TIMESTAMP: 2025-05-04 19:10:27
import sys
sys.dont_write_bytecode = True
import os

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'your_secret_key_here')
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', 'your_bot_token_here')