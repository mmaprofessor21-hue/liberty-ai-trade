# TIMESTAMP: 2025-05-04 17:12:12
import os

API_KEY = os.getenv("API_KEY", "default_key")
DB_PATH = "liberty_trade.db"