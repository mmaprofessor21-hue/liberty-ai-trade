# TIMESTAMP: 2025-05-04 17:12:12
import sqlite3

def init_db():
    conn = sqlite3.connect("liberty_trade.db")
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT,
        amount REAL,
        action TEXT,
        timestamp TEXT
    )
    """)
    conn.commit()
    conn.close()