# TIMESTAMP: 2025-05-04 17:12:12
class Settings:
    PROJECT_NAME: str = "Liberty AI Trade"
    VERSION: str = "1.0.0"
    DEBUG: bool = True