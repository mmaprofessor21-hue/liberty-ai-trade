# TIMESTAMP: 2025-05-04 17:12:12
def execute_trade(token: str, amount: float, action: str):
    print(f"Executing {action} of {amount} {token}")