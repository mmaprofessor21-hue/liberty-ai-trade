# TIMESTAMP: 2025-05-04 17:12:12
def verify_api_key(key: str) -> bool:
    return key == "secure_admin_key"