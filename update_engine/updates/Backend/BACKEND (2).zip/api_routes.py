# TIMESTAMP: 2025-05-04 17:12:12
from fastapi import APIRouter

router = APIRouter()

@router.get("/api/health")
async def health_check():
    return {"status": "ok"}