# bulk_update.py
# PHASE O-7 — TradingViewPanel AUDIT (READ-ONLY)
# NO MOVES | NO RENAMES | NO IMPORT REWRITES

import sys
sys.dont_write_bytecode = True

from pathlib import Path

print("[BULK] Phase O-7 — TradingViewPanel AUDIT (READ-ONLY) START")

PROJECT_ROOT = Path(__file__).resolve().parents[2]
TV_ROOT = PROJECT_ROOT / "Frontend" / "src" / "components" / "TradingView"
PANEL_FILE = TV_ROOT / "TradingViewPanel.js"

# -----------------------------
# AUDIT TradingViewPanel
# -----------------------------
if not PANEL_FILE.exists():
    print("[AUDIT][ERROR] TradingViewPanel.js not found")
else:
    print(f"[AUDIT] Reading: {PANEL_FILE}")

    content = PANEL_FILE.read_text(encoding="utf-8", errors="ignore")

    overlay_imports = []
    engine_imports = []
    indicator_imports = []
    sentiment_imports = []
    render_controls = []

    for line in content.splitlines():
        l = line.strip()

        if l.startswith("import"):
            if "Overlay" in l:
                overlay_imports.append(l)
            if "Engine" in l:
                engine_imports.append(l)
            if "Indicator" in l:
                indicator_imports.append(l)
            if "Sentiment" in l:
                sentiment_imports.append(l)

        if "<" in l and "Overlay" in l:
            render_controls.append(l)

    for l in overlay_imports:
        print(f"[AUDIT][OVERLAY_IMPORT] {l}")

    for l in engine_imports:
        print(f"[AUDIT][ENGINE_IMPORT] {l}")

    for l in indicator_imports:
        print(f"[AUDIT][INDICATOR_IMPORT] {l}")

    for l in sentiment_imports:
        print(f"[AUDIT][SENTIMENT_IMPORT] {l}")

    for l in render_controls:
        print(f"[AUDIT][RENDER_CONTROL] {l}")

# -----------------------------
# REQUIRED TEST FILE UPDATES
# -----------------------------
frontend_test = PROJECT_ROOT / "Frontend" / "src" / "components" / "tests" / "test_update.js"
backend_test = PROJECT_ROOT / "Backend" / "tests" / "test_update.py"

try:
    frontend_test.write_text(
        frontend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n// O-7 TradingViewPanel audit executed\n",
        encoding="utf-8",
    )
    print(f"[BULK] UPDATED TEST FILE: {frontend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Frontend test update failed: {e}")

try:
    backend_test.write_text(
        backend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n# O-7 TradingViewPanel audit executed\n",
        encoding="utf-8",
    )
    print(f"[BULK] UPDATED TEST FILE: {backend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Backend test update failed: {e}")

print("[BULK] Phase O-7 — TradingViewPanel AUDIT COMPLETE")
