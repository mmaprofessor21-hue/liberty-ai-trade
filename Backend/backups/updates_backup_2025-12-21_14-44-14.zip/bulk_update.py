# bulk_update.py
# DO NOT ADD LOGIC OUTSIDE FILE-WRITE INJECTIONS.
# This file is executed by the updater. It must write full target files.
# ASCII ONLY. UTF-8 WRITES ONLY.

import os
from datetime import datetime

# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def _now_stamp():
    # The core will inject the official system timestamp where applicable.
    # Keep this stable and ASCII.
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

def _write_utf8(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)

# ---------------------------------------------------------------------
# Required test files (must update every run)
# ---------------------------------------------------------------------

FRONTEND_TEST_PATH = os.path.join("Frontend", "src", "components", "tests", "test_update.js")
BACKEND_TEST_PATH  = os.path.join("Backend", "tests", "test_update.py")

frontend_test_content = (
    "// This file is required by the updater pipeline.\n"
    "// TIMESTAMP: PLACEHOLDER (core injects)\n"
    "export default function test_update() {\n"
    "  return \"updater_test_ok\";\n"
    "}\n"
)

backend_test_content = (
    "# This file is required by the updater pipeline.\n"
    "# TIMESTAMP: PLACEHOLDER (core injects)\n"
    "def test_update():\n"
    "    return \"updater_test_ok\"\n"
)

# ---------------------------------------------------------------------
# TradingView container contract (NO vertical caps, organic growth)
# ---------------------------------------------------------------------

TV_PANEL_CSS_PATH = os.path.join("Frontend", "src", "components", "TradingView", "TradingViewPanel.css")
CHART_CONTAINER_CSS_PATH = os.path.join("Frontend", "src", "components", "TradingView", "ChartContainer.css")
TV_CHART_SECTION_CSS_PATH = os.path.join("Frontend", "src", "components", "TradingView", "TradingViewChartSection.css")

tv_panel_css = (
    "/* DO NOT MODIFY OUTSIDE UPDATE PIPELINE */\n"
    "/* TIMESTAMP: PLACEHOLDER (core injects) */\n"
    "\n"
    "/*\n"
    "  TradingView Panel - Height Contract (LOCKED)\n"
    "  - Docked: organic height, no hard caps\n"
    "  - Floating: may be constrained by its own window wrapper\n"
    "*/\n"
    "\n"
    ".tv-panel-wrapper {\n"
    "  width: 100%;\n"
    "}\n"
    "\n"
    ".tv-ai-controls-wrapper {\n"
    "  margin-bottom: 15px;\n"
    "}\n"
    "\n"
    "/* Docked container must NOT hard-cap height */\n"
    ".tv-container.docked {\n"
    "  position: relative;\n"
    "  width: 100%;\n"
    "  height: auto;\n"
    "  min-height: 520px;\n"
    "  margin-top: 15px;\n"
    "  display: flex;\n"
    "  flex-direction: column;\n"
    "  overflow: hidden;\n"
    "}\n"
    "\n"
    "/* Floating container may be sized by the floating window. Still fill it. */\n"
    ".tv-container.floating {\n"
    "  position: relative;\n"
    "  width: 100%;\n"
    "  height: 100%;\n"
    "  min-height: 520px;\n"
    "  display: flex;\n"
    "  flex-direction: column;\n"
    "  overflow: hidden;\n"
    "}\n"
    "\n"
    "/* The widget wrapper should always expand */\n"
    ".tv-widget-container {\n"
    "  width: 100%;\n"
    "  flex: 1;\n"
    "  min-height: 520px;\n"
    "  height: auto;\n"
    "  position: relative;\n"
    "  overflow: hidden;\n"
    "}\n"
    "\n"
    ".tv-widget-inner {\n"
    "  width: 100%;\n"
    "  height: 100%;\n"
    "  min-height: 520px;\n"
    "}\n"
    "\n"
    "/* Safe styling for overlay chips/labels if present */\n"
    ".tv-chip {\n"
    "  display: inline-flex;\n"
    "  align-items: center;\n"
    "  gap: 8px;\n"
    "  padding: 6px 10px;\n"
    "  border: 1px solid rgba(255, 255, 255, 0.18);\n"
    "  border-radius: 999px;\n"
    "  font-size: 12px;\n"
    "  letter-spacing: 0.3px;\n"
    "  background: rgba(0, 0, 0, 0.25);\n"
    "}\n"
    "\n"
    ".tv-chip-long {\n"
    "  border-color: rgba(34, 197, 94, 0.8);\n"
    "  color: rgba(34, 197, 94, 0.95);\n"
    "}\n"
    "\n"
    ".tv-chip-short {\n"
    "  border-color: rgba(248, 113, 113, 0.8);\n"
    "  color: rgba(248, 113, 113, 0.95);\n"
    "}\n"
    "\n"
    ".tv-overlay-metric {\n"
    "  opacity: 0.9;\n"
    "}\n"
)

chart_container_css = (
    "/* DO NOT MODIFY OUTSIDE UPDATE PIPELINE */\n"
    "/* TIMESTAMP: PLACEHOLDER (core injects) */\n"
    "\n"
    "/*\n"
    "  ChartContainer CSS Contract\n"
    "  Goal: remove vertical restrictions and allow TradingView iframe to fill.\n"
    "*/\n"
    "\n"
    ".chart-container,\n"
    ".tv-chart-container,\n"
    ".tv-container,\n"
    ".tv-widget-container {\n"
    "  width: 100%;\n"
    "}\n"
    "\n"
    "/* If ChartContainer is a flex child, it must be allowed to grow */\n"
    ".chart-container,\n"
    ".tv-chart-container {\n"
    "  position: relative;\n"
    "  flex: 1;\n"
    "  height: auto;\n"
    "  min-height: 520px;\n"
    "  overflow: hidden;\n"
    "}\n"
    "\n"
    "/* Common TradingView iframe selector patterns */\n"
    ".chart-container iframe,\n"
    ".tv-chart-container iframe,\n"
    ".tv-widget-container iframe,\n"
    ".tv-widget-inner iframe,\n"
    "#tv_chart_container iframe {\n"
    "  width: 100% !important;\n"
    "  height: 100% !important;\n"
    "  min-height: 520px !important;\n"
    "  border: 0 !important;\n"
    "  display: block;\n"
    "}\n"
    "\n"
    "/* If the library injects nested divs, force fill */\n"
    ".tv-widget-container > div,\n"
    ".tv-widget-inner,\n"
    "#tv_chart_container {\n"
    "  width: 100%;\n"
    "  height: 100%;\n"
    "  min-height: 520px;\n"
    "}\n"
)

tv_chart_section_css = (
    "/* DO NOT MODIFY OUTSIDE UPDATE PIPELINE */\n"
    "/* TIMESTAMP: PLACEHOLDER (core injects) */\n"
    "\n"
    "/*\n"
    "  TradingViewChartSection layout contract\n"
    "  - No hard vertical caps\n"
    "  - Allow organic expansion\n"
    "*/\n"
    "\n"
    ".tradingview-section,\n"
    ".tradingview-chart-section,\n"
    ".tradingview-chart,\n"
    ".tv-section {\n"
    "  width: 100%;\n"
    "}\n"
    "\n"
    ".tradingview-section,\n"
    ".tradingview-chart-section,\n"
    ".tv-section {\n"
    "  display: flex;\n"
    "  flex-direction: column;\n"
    "  height: auto;\n"
    "  min-height: 520px;\n"
    "  overflow: visible;\n"
    "}\n"
    "\n"
    "/* The chart area must be a growing region */\n"
    ".tradingview-chart,\n"
    ".tv-chart-area,\n"
    ".tv-container {\n"
    "  flex: 1;\n"
    "  height: auto;\n"
    "  min-height: 520px;\n"
    "  overflow: hidden;\n"
    "}\n"
)

# ---------------------------------------------------------------------
# Apply writes (these must appear in terminal as [BULK] file entries)
# ---------------------------------------------------------------------

_write_utf8(TV_PANEL_CSS_PATH, tv_panel_css)
_write_utf8(CHART_CONTAINER_CSS_PATH, chart_container_css)
_write_utf8(TV_CHART_SECTION_CSS_PATH, tv_chart_section_css)

_write_utf8(FRONTEND_TEST_PATH, frontend_test_content)
_write_utf8(BACKEND_TEST_PATH, backend_test_content)
