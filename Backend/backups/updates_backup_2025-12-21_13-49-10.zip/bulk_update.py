#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

# ---------------------------------------------------------
# README COMPLIANCE:
# - WRITE ONLY داخل update_engine/updates/ (drop zone)
# - NO live folder writes
# - PRINT [BULK] lines per updated file
# - PRINT final success line with exact count
# - NO timestamps (core injects)
# - NO updater_core imports
# ---------------------------------------------------------

DROP_ZONE_DIR = os.path.dirname(os.path.abspath(__file__))

def _write(rel_path, content):
    """
    rel_path is relative to update_engine/updates/
    """
    abs_path = os.path.join(DROP_ZONE_DIR, rel_path.replace("/", os.sep))
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {rel_path}")

def main():
    written = 0

    # ---------------------------------------------------------
    # TradingView: ChartContainer.js (single source of truth)
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/TradingView/ChartContainer.js",
        """\
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

import React from "react";
import "./ChartContainer.css";

export const TRADINGVIEW_CONTAINER_ID = "tradingview-chart";

export default function ChartContainer() {
  return (
    <div
      id={TRADINGVIEW_CONTAINER_ID}
      className="tradingview-chart-container"
    />
  );
}
"""
    )
    written += 1

    # ---------------------------------------------------------
    # TradingView: TradingViewController.js (no container guessing)
    # NOTE: This does NOT assume tv-init.js or widget.js exist.
    # It only uses window.TradingView if it is present.
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/TradingView/TradingViewController.js",
        """\
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

import { useEffect } from "react";
import { TRADINGVIEW_CONTAINER_ID } from "./ChartContainer";

export default function TradingViewController() {
  useEffect(() => {
    const id = TRADINGVIEW_CONTAINER_ID;

    if (!id || typeof id !== "string" || id.trim().length === 0) {
      console.error("[TradingViewController] Invalid container id:", id);
      return;
    }

    const container = document.getElementById(id);
    if (!container) {
      console.error("[TradingViewController] Container not found:", id);
      return;
    }

    // Avoid double-mount if widget already rendered children
    if (container.childNodes && container.childNodes.length > 0) return;

    // Do not assume any extra files exist. Only proceed if TradingView is available.
    if (!window || !window.TradingView || !window.TradingView.widget) {
      // Keep UI stable; do not throw. This prevents SES_UNCAUGHT_EXCEPTION cascades.
      console.warn("[TradingViewController] TradingView.widget not available on window yet");
      return;
    }

    try {
      new window.TradingView.widget({
        container_id: id,
        symbol: "BINANCE:BTCUSDT",
        interval: "15",
        timezone: "Etc/UTC",
        theme: "dark",
        style: "1",
        locale: "en",
        autosize: true,
        allow_symbol_change: true
      });
    } catch (e) {
      console.error("[TradingViewController] Failed to initialize widget:", e);
    }
  }, []);

  return null;
}
"""
    )
    written += 1

    # ---------------------------------------------------------
    # TradingView: TradingViewChartSection.js (composition only)
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/TradingView/TradingViewChartSection.js",
        """\
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

import ChartContainer from "./ChartContainer";
import TradingViewController from "./TradingViewController";
import "./TradingViewChartSection.css";

export default function TradingViewChartSection() {
  return (
    <section className="tradingview-section">
      <ChartContainer />
      <TradingViewController />
    </section>
  );
}
"""
    )
    written += 1

    # ---------------------------------------------------------
    # MANDATORY UPDATER TEST FILES (updates folder only)
    # MUST be overwritten EVERY run (Section 5)
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/tests/test_update.js",
        """\
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

console.log("Updater mandatory test_update.js executed (drop zone)");
"""
    )
    written += 1

    _write(
        "Backend/tests/test_update.py",
        """\
# 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

print("Updater mandatory test_update.py executed (drop zone)")
"""
    )
    written += 1

    print(f"[BULK] Successfully processed {written} files")

if __name__ == "__main__":
    main()
