// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useEffect, useRef } from "react";
import "./TradingViewController.css";

export default function TradingViewController() {
  const chartRef = useRef(null);
  const widgetRef = useRef(null);
  const observerRef = useRef(null);

  useEffect(() => {
    if (!chartRef.current) return;
    if (widgetRef.current) return;

    if (!window.TradingView || !window.TradingView.widget) {
      console.warn("[TradingView] tv.js not loaded yet");
      return;
    }

    const container = chartRef.current;

    const tryInit = () => {
      const width = container.offsetWidth;
      const height = container.offsetHeight;

      if (width === 0 || height === 0) return;
      if (widgetRef.current) return;

      widgetRef.current = new window.TradingView.widget({
        autosize: true,
        symbol: "BINANCE:BTCUSDT",
        interval: "15",
        timezone: "Etc/UTC",
        theme: "dark",
        style: "1",
        locale: "en",
        container: container,
        hide_top_toolbar: true,
        hide_legend: true,
        allow_symbol_change: true,
      });

      if (observerRef.current) {
        observerRef.current.disconnect();
        observerRef.current = null;
      }
    };

    observerRef.current = new ResizeObserver(tryInit);
    observerRef.current.observe(container);

    tryInit();

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
        observerRef.current = null;
      }
    };
  }, []);

  return (
    <div className="tv-panel">
      <div className="tv-panel-inner">
        <div className="tv-chart-shell" ref={chartRef}>
          <div className="tv-placeholder">Loading chart…</div>
        </div>
      </div>
    </div>
  );
}
