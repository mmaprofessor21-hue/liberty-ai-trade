#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os
import shutil

BASE_DIR = os.path.dirname(__file__)
files_processed = 0

def move(src, dst):
    global files_processed
    src_path = os.path.join(BASE_DIR, src)
    dst_path = os.path.join(BASE_DIR, dst)

    if not os.path.exists(src_path):
        print(f"[SKIP] Missing: {src}")
        return

    os.makedirs(os.path.dirname(dst_path), exist_ok=True)
    shutil.move(src_path, dst_path)
    print(f"[MOVED] {src} → {dst}")
    files_processed += 1


# ============================================================
# WALLET LEGACY BACKEND-PREP ISOLATION (MOVE-ONLY)
# ------------------------------------------------------------
# RULES:
# - NO deletions
# - NO file edits
# - NO import changes
# - NO behavior changes
# ============================================================

move(
    "Frontend/src/components/Wallet/WalletStatus.js",
    "Frontend/src/components/Wallet/_legacy_backend_prep/WalletStatus.js"
)

move(
    "Frontend/src/components/Wallet/WalletSecurity.js",
    "Frontend/src/components/Wallet/_legacy_backend_prep/WalletSecurity.js"
)

move(
    "Frontend/src/components/Wallet/WalletData.js",
    "Frontend/src/components/Wallet/_legacy_backend_prep/WalletData.js"
)

# Optional legacy variants (only if present — safe move)
move(
    "Frontend/src/components/Wallet/WalletStatusBlock.js",
    "Frontend/src/components/Wallet/_legacy_backend_prep/WalletStatusBlock.js"
)

move(
    "Frontend/src/components/Wallet/WalletSecurityBlock.js",
    "Frontend/src/components/Wallet/_legacy_backend_prep/WalletSecurityBlock.js"
)

move(
    "Frontend/src/components/Wallet/WalletDataBlock.js",
    "Frontend/src/components/Wallet/_legacy_backend_prep/WalletDataBlock.js"
)

print(f"[BULK] Isolation complete — {files_processed} file(s) moved")
