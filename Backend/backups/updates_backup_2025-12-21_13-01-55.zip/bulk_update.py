#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE = os.path.dirname(__file__)
FILES = {}

def write(path, content):
    full = os.path.join(BASE, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {path}")
    FILES[path] = True


# -------------------------------------------------
# TradingViewWidget.js
# FULL FILE — LEGACY AUTO-EXECUTION REMOVED
# This file is now a PASSIVE helper only.
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewWidget.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

// NOTE:
// This file previously auto-instantiated a TradingView widget on import.
// That behavior is NO LONGER VALID.
//
// TradingViewController is now the SOLE widget mount owner.
// This file is preserved as a future helper/factory only.

export function createTradingViewWidget(config) {
  if (!window.TradingView || !window.TradingView.widget) {
    console.warn("[TradingViewWidget] TradingView library not loaded");
    return null;
  }

  if (!config || !config.container) {
    console.warn("[TradingViewWidget] Invalid config or missing container");
    return null;
  }

  return new window.TradingView.widget({
    autosize: true,
    symbol: config.symbol || "BINANCE:BTCUSDT",
    interval: config.interval || "15",
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    container: config.container,
    hide_top_toolbar: true,
    hide_legend: true,
    allow_symbol_change: true,
  });
}
"""
)


# -------------------------------------------------
# MANDATORY TEST FILES (REQUIRED EVERY RUN)
# -------------------------------------------------
write(
    "Frontend/src/components/tests/test_update.js",
    """// updater test file
export const UPDATE_TEST = "TradingViewWidget auto-execution removed";
"""
)

write(
    "Backend/tests/test_update.py",
    "# updater test file\nUPDATE_TEST = 'TradingViewWidget auto-execution removed'\n"
)

print(f"[BULK] Successfully processed {len(FILES)} files")
