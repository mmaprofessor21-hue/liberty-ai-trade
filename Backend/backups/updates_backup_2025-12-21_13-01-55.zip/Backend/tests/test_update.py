# updater test file
UPDATE_TEST = 'TradingViewController DOM-safe initialization'
