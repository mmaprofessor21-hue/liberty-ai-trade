#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE = os.path.dirname(__file__)
FILES = {}

def write(path, content):
    full = os.path.join(BASE, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {path}")
    FILES[path] = True


# -------------------------------------------------
# TradingViewChartSection.js
# FULL FILE — stale AISignalOverlay import removed
# ALL other logic preserved
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewChartSection.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useState } from "react";
import "./TradingViewChartSection.css";

import TradingViewController from "./TradingViewController";

export default function TradingViewChartSection() {
  const [isDocked, setIsDocked] = useState(true);

  return (
    <div className="tv-section">
      <div className="tv-dock-toggle">
        <button
          className="tv-dock-button"
          onClick={() => setIsDocked(!isDocked)}
        >
          {isDocked ? "Undock Chart" : "Dock Chart"}
        </button>
      </div>

      <div className="tv-chart-container">
        <TradingViewController />
      </div>
    </div>
  );
}
"""
)


# -------------------------------------------------
# MANDATORY TEST FILES (REQUIRED EVERY RUN)
# -------------------------------------------------
write(
    "Frontend/src/components/tests/test_update.js",
    """// updater test file
export const UPDATE_TEST = "TradingViewChartSection stale import removal";
"""
)

write(
    "Backend/tests/test_update.py",
    "# updater test file\nUPDATE_TEST = 'TradingViewChartSection stale import removal'\n"
)

print(f"[BULK] Successfully processed {len(FILES)} files")
