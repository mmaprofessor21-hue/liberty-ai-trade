# updater test file
UPDATE_TEST = 'TradingView Feature Phase'
