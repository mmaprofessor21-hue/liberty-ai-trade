// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

export default function TradingViewWidget({ container, symbol }) {
  if (!window.TradingView) return null;

  const widget = new window.TradingView.widget({
    container_id: container,
    autosize: true,
    symbol: symbol,
    interval: "15",
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    enable_publishing: false,
    hide_top_toolbar: false,
    hide_legend: false,
    save_image: false,
  });

  return widget;
}
