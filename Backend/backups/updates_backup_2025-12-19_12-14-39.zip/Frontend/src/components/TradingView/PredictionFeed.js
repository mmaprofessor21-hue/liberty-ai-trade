
/**
 * PART 5C — PREDICTION FEED (SIMULATED)
 *
 * Backend websocket will replace this in the future.
 *
 * Emits a predicted BUY/SELL every 30–60 seconds.
 */

import { generateAIPrediction } from "./AIPredictionEngine";

export function startPredictionFeed(callback, token, strategy, sentiment, strategyConf) {

    const generate = () => {
        const result = generateAIPrediction(token, strategy, sentiment, strategyConf);
        callback(result);
    };

    generate();

    const interval = setInterval(() => {
        generate();
    }, 30000 + Math.random() * 30000);

    return () => clearInterval(interval);
}
