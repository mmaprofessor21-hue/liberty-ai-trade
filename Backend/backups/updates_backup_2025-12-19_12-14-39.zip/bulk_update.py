#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True
import os

print("[BULK] Executing bulk_update.py ...")

written_files = []

def write_file(rel_path, content):
    abs_path = os.path.join(os.path.dirname(__file__), rel_path)
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {rel_path}")
    written_files.append(rel_path)

# ------------------------------------------------------------------
# WALLET ROOT — RESTORE BACKGROUND WRAPPER (NO LOGIC CHANGE)
# ------------------------------------------------------------------
write_file(
    "Frontend/src/components/Wallet/WalletRoot.js",
    """// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

import React from "react";
import "./WalletRoot.css";
import "./WalletBackground.css";

import WalletStatus from "./WalletStatus";
import WalletSecurityControls from "./WalletSecurityControls";
import WalletData from "./WalletData";

export default function WalletRoot() {
  return (
    <div className="wallet-background">
      <div className="wallet-root">
        <WalletStatus />
        <WalletSecurityControls />
        <WalletData />
      </div>
    </div>
  );
}
"""
)

# ------------------------------------------------------------------
# WALLET BACKGROUND CSS — RE-ENABLE BACKGROUND (NO HEIGHT LIMITS)
# ------------------------------------------------------------------
write_file(
    "Frontend/src/components/Wallet/WalletBackground.css",
    """/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */

.wallet-background {
  position: relative;
  width: 100%;
  min-height: 0;

  background-image: url("../../assets/Main_Liberty_background.png");
  background-repeat: no-repeat;
  background-position: center top;
  background-size: cover;

  overflow: visible;
}
"""
)

# ------------------------------------------------------------------
# MANDATORY FRONTEND TEST FILE (ALWAYS UPDATED)
# ------------------------------------------------------------------
write_file(
    "Frontend/src/components/tests/test_update.js",
    """// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

export default function test_update() {
  return "frontend updater test";
}
"""
)

# ------------------------------------------------------------------
# MANDATORY BACKEND TEST FILE (ALWAYS UPDATED)
# ------------------------------------------------------------------
write_file(
    "Backend/tests/test_update.py",
    """# 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

def test_update():
    return "backend updater test"
"""
)

print(f"[BULK] Successfully processed {len(written_files)} files")
