import sys
sys.dont_write_bytecode = True

from pathlib import Path

print("[BULK] Phase O-10 - TradingView ENTRY OWNER TAGGING START")

PROJECT_ROOT = Path(__file__).resolve().parents[2]

TARGETS = {
    "Frontend/src/components/TradingView/TradingViewChartSection.js":
        "// OWNER: App.js\n// ROLE: Primary TradingView mount point\n",

    "Frontend/src/components/TradingView/TradingViewPanel.js":
        "// OWNER: TradingViewChartSection\n// ROLE: TradingView layout orchestrator\n",

    "Frontend/src/components/TradingView/TradingViewDock.js":
        "// OWNER: TradingViewPanel\n// ROLE: Docked TradingView container\n",

    "Frontend/src/components/TradingView/TradingViewWidget.js":
        "// OWNER: TradingViewPanel\n// ROLE: TradingView widget shell\n",

    "Frontend/src/components/TradingView/TradingViewController.js":
        "// OWNER: TradingViewDock\n// ROLE: TradingView controller + overlay hook\n",

    "Frontend/src/components/TradingView/core/ChartContainer.js":
        "// OWNER: TradingViewController\n// ROLE: TradingView chart container (engine attach point)\n",
}

for rel_path, header in TARGETS.items():
    file_path = PROJECT_ROOT / rel_path
    if not file_path.exists():
        print(f"[BULK][SKIP] Missing: {rel_path}")
        continue

    try:
        content = file_path.read_text(encoding="utf-8", errors="ignore")
        if header.strip() in content:
            print(f"[BULK] NO CHANGE: {rel_path}")
            continue

        file_path.write_text(
            header + "\n" + content,
            encoding="utf-8"
        )
        print(f"[BULK] TAGGED OWNER: {rel_path}")

    except Exception as e:
        print(f"[BULK][ERROR] {rel_path}: {e}")

# Required test file visibility
frontend_test = PROJECT_ROOT / "Frontend/src/components/tests/test_update.js"
backend_test = PROJECT_ROOT / "Backend/tests/test_update.py"

try:
    frontend_test.write_text(
        frontend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n// O-10 TradingView entry ownership tagging applied\n",
        encoding="utf-8"
    )
    print(f"[BULK] UPDATED TEST FILE: {frontend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Frontend test update failed: {e}")

try:
    backend_test.write_text(
        backend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n# O-10 TradingView entry ownership tagging applied\n",
        encoding="utf-8"
    )
    print(f"[BULK] UPDATED TEST FILE: {backend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Backend test update failed: {e}")

print("[BULK] Phase O-10 - TradingView ENTRY OWNER TAGGING COMPLETE")
