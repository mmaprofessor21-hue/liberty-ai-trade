export default function WalletSecurity() {
  return (
    <div className="wallet-section wallet-security">
      <div className="wallet-security-led wallet-led-unsafe">UNSAFE</div>
    </div>
  );
}
