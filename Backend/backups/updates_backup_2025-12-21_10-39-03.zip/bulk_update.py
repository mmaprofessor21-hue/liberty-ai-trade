import sys
sys.dont_write_bytecode = True

from pathlib import Path
import re

print("[BULK] Phase O-11 - Overlay → Controller ATTACHMENT AUDIT (READ-ONLY) START")

PROJECT_ROOT = Path(__file__).resolve().parents[2]

CONTROLLER = PROJECT_ROOT / "Frontend/src/components/TradingView/TradingViewController.js"
OVERLAY_ROOT = PROJECT_ROOT / "Frontend/src/components/TradingView/overlays"

if not CONTROLLER.exists():
    print("[AUDIT][ERROR] TradingViewController.js not found")
else:
    print(f"[AUDIT] Reading controller: {CONTROLLER}")
    content = CONTROLLER.read_text(encoding="utf-8", errors="ignore")

    hooks = re.findall(r"overlay|attach|mount|hook", content, re.IGNORECASE)
    print(f"[AUDIT] Controller overlay hook references found: {len(hooks)}")

if OVERLAY_ROOT.exists():
    for overlay in OVERLAY_ROOT.rglob("*.js"):
        try:
            text = overlay.read_text(encoding="utf-8", errors="ignore")
            if "TradingViewController" in text:
                print(f"[AUDIT][OVERLAY_REF] {overlay}")
            else:
                print(f"[AUDIT][PASSIVE] {overlay.name}")
        except Exception as e:
            print(f"[AUDIT][ERROR] {overlay}: {e}")
else:
    print("[AUDIT][ERROR] overlays folder missing")

# Required test visibility
frontend_test = PROJECT_ROOT / "Frontend/src/components/tests/test_update.js"
backend_test = PROJECT_ROOT / "Backend/tests/test_update.py"

frontend_test.write_text(
    frontend_test.read_text(encoding="utf-8", errors="ignore")
    + "\n// O-11 Overlay → Controller attachment audit executed\n",
    encoding="utf-8"
)

backend_test.write_text(
    backend_test.read_text(encoding="utf-8", errors="ignore")
    + "\n# O-11 Overlay → Controller attachment audit executed\n",
    encoding="utf-8"
)

print("[BULK] Phase O-11 - Overlay → Controller ATTACHMENT AUDIT COMPLETE")
