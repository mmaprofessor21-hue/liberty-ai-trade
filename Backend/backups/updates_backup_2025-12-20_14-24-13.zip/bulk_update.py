#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os
import shutil

# DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

BASE = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "TradingView"
)

EXPERIMENT_FILES = [
    "TestChart.js",
    "DebugChart.js",
    "SandboxChart.js",
    "PrototypeOverlay.js",
    "TempOverlay.js",
    "OldTradingView.js",
]

print("[BULK] TradingView experiments isolation START")

for fname in EXPERIMENT_FILES:
    src = os.path.join(BASE, fname)
    dst = os.path.join(BASE, "experiments", fname)

    if os.path.exists(src):
        shutil.move(src, dst)
        print(
            "[BULK] MOVED FILE: Frontend/src/components/TradingView/"
            + fname
            + " -> TradingView/experiments/"
            + fname
        )
    else:
        print("[BULK] SKIPPED (not found): TradingView/" + fname)

# ------------------------------------------------------------
# MANDATORY UPDATER TEST FILES (REQUIRED EVERY RUN)
# ------------------------------------------------------------

frontend_test_path = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "tests",
    "test_update.js"
)

backend_test_path = os.path.join(
    "update_engine",
    "updates",
    "Backend",
    "tests",
    "test_update.py"
)

os.makedirs(os.path.dirname(frontend_test_path), exist_ok=True)
os.makedirs(os.path.dirname(backend_test_path), exist_ok=True)

with open(frontend_test_path, "w", encoding="utf-8") as f:
    f.write(
        "// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt\n"
        "// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE\n\n"
        "export default function testUpdate() {\n"
        "  return 'frontend updater test';\n"
        "}\n"
    )

print("[BULK] UPDATED TEST FILE: Frontend/src/components/tests/test_update.js")

with open(backend_test_path, "w", encoding="utf-8") as f:
    f.write(
        "# DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt\n"
        "# NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE\n\n"
        "def test_update():\n"
        "    return 'backend updater test'\n"
    )

print("[BULK] UPDATED TEST FILE: Backend/tests/test_update.py")

print("[BULK] TradingView experiments isolation COMPLETE")
