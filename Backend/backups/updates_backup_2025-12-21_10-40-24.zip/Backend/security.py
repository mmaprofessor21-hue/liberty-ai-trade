# P25-06-04_14-47-51
def verify_api_key(key: str) -> bool:
    return key == "secure_admin_key"
