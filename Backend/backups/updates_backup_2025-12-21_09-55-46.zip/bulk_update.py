import sys
sys.dont_write_bytecode = True

from pathlib import Path

print("[BULK] Phase O-3 — Sentiment imports verification START")

PROJECT_ROOT = Path.cwd()
TV_ROOT = PROJECT_ROOT / "Frontend" / "src" / "components" / "TradingView"
SENTIMENT_ROOT = TV_ROOT / "overlays" / "sentiment"

SENTIMENT_FILES = [
    SENTIMENT_ROOT / "SentimentMeter.js",
    SENTIMENT_ROOT / "SentimentSourceSelector.js",
]

def verify_sentiment_imports(file_path: Path):
    if not file_path.exists():
        print(f"[BULK] SKIPPED (not found): {file_path.relative_to(PROJECT_ROOT)}")
        return

    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"[BULK][ERROR] Read failed: {file_path.name} -> {e}")
        return

    updated = False
    lines = content.splitlines()
    rewritten = []

    for line in lines:
        original = line

        # SAFE normalization only (no assumptions)
        if "../SentimentMeter" in line:
            line = line.replace("../SentimentMeter", "./SentimentMeter")
        if "../SentimentSourceSelector" in line:
            line = line.replace("../SentimentSourceSelector", "./SentimentSourceSelector")

        if line != original:
            updated = True

        rewritten.append(line)

    if updated:
        file_path.write_text("\n".join(rewritten) + "\n", encoding="utf-8")
        print(f"[BULK] UPDATED IMPORTS: {file_path.relative_to(PROJECT_ROOT)}")
    else:
        print(f"[BULK] NO CHANGE: {file_path.relative_to(PROJECT_ROOT)}")

# ---- Execute verification ----
for sentiment_file in SENTIMENT_FILES:
    verify_sentiment_imports(sentiment_file)

# ---- REQUIRED TEST FILE UPDATE (README compliance) ----
frontend_test = PROJECT_ROOT / "Frontend" / "src" / "components" / "tests" / "test_update.js"
backend_test = PROJECT_ROOT / "Backend" / "tests" / "test_update.py"

if frontend_test.exists():
    frontend_test.write_text(
        frontend_test.read_text(encoding="utf-8") + "\n// Phase O-3 sentiment verification\n",
        encoding="utf-8",
    )
    print("[BULK] UPDATED TEST FILE:", frontend_test.relative_to(PROJECT_ROOT))

if backend_test.exists():
    backend_test.write_text(
        backend_test.read_text(encoding="utf-8") + "\n# Phase O-3 sentiment verification\n",
        encoding="utf-8",
    )
    print("[BULK] UPDATED TEST FILE:", backend_test.relative_to(PROJECT_ROOT))

print("[BULK] Phase O-3 — Sentiment imports verification COMPLETE")
