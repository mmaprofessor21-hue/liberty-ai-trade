# 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# bulk_update.py — TradingView Container Contract
# TIMESTAMP: 2025-12-21_14-35-00

FILES = {

# =========================================================
# TradingViewController.js
# =========================================================
"Frontend/src/components/TradingView/TradingViewController.js": """
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER.txt
// TIMESTAMP: 2025-12-21_14-35-00

import React from "react";
import ChartContainer from "./ChartContainer";
import "./TradingViewController.css";

export default function TradingViewController() {
  return (
    <section className="tradingview-controller">
      <ChartContainer />
    </section>
  );
}
""",

# =========================================================
# ChartContainer.js
# =========================================================
"Frontend/src/components/TradingView/ChartContainer.js": """
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER.txt
// TIMESTAMP: 2025-12-21_14-35-00

import React from "react";
import "./ChartContainer.css";

export default function ChartContainer() {
  return (
    <div className="chart-container">
      <iframe
        title="TradingView Chart"
        src="https://www.tradingview.com/chart/"
        frameBorder="0"
        allowFullScreen
      />
    </div>
  );
}
""",

# =========================================================
# ChartContainer.css
# =========================================================
"Frontend/src/components/TradingView/ChartContainer.css": """
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER.txt */
/* TIMESTAMP: 2025-12-21_14-35-00 */

.chart-container {
  width: 100%;
  height: auto;
  min-height: 420px;
  display: block;
  position: relative;
  overflow: visible;
}

.chart-container iframe {
  width: 100%;
  height: 100%;
  min-height: 420px;
  border: none;
  display: block;
}
""",

# =========================================================
# TradingViewChartSection.css
# =========================================================
"Frontend/src/components/TradingView/TradingViewChartSection.css": """
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER.txt */
/* TIMESTAMP: 2025-12-21_14-35-00 */

.tradingview-section {
  width: 100%;
  height: auto;
  min-height: unset;
  max-height: unset;
  overflow: visible;
  display: block;
}
""",

# =========================================================
# REQUIRED TEST FILES (UNCHANGED, REQUIRED BY UPDATER)
# =========================================================
"Frontend/src/components/tests/test_update.js": """
// TIMESTAMP: 2025-12-21_14-35-00
console.log("TradingView updater test file present");
""",

"Backend/tests/test_update.py": """
# TIMESTAMP: 2025-12-21_14-35-00
print("TradingView backend updater test file present")
"""
}

def run():
    return FILES
