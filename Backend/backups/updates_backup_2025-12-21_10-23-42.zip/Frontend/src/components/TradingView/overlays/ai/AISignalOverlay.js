/* TIMESTAMP: 2025-12-09_20-12-41 */
import React from 'react';

export default function AISignalOverlay() {
  return (
    <div className="tv-overlay-banner">
      <span>AI Overlay Active</span>
    </div>
  );
}
