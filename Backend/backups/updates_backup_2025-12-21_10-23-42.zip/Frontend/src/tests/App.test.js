test("App renders with WalletRoot mounted", () => {
  expect(true).toBe(true);
});
