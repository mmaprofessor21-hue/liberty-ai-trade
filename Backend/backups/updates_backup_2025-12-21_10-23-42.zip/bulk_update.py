# ============================================================
# Phase O-8 — ChartContainer Ownership AUDIT (READ-ONLY)
# ============================================================
# 🚨 READ-ONLY AUDIT
# ❌ NO FILE MODIFICATIONS
# ❌ NO IMPORT REWRITES
# ✅ LOG OWNERSHIP & DEPENDENCIES ONLY
# ============================================================

from pathlib import Path

ROOT = Path("Frontend/src/components/TradingView")

TARGETS = [
    ROOT / "core" / "ChartContainer.js",
    ROOT / "TradingViewController.js",
    ROOT / "OverlayManager.js",
    ROOT / "DockManager.js",
]

print("[BULK] Phase O-8 — ChartContainer ownership AUDIT (READ-ONLY) START")

for file in TARGETS:
    if not file.exists():
        print(f"[AUDIT][SKIP] Missing: {file}")
        continue

    print(f"[AUDIT] Reading: {file}")

    try:
        content = file.read_text(encoding="utf-8", errors="ignore")
    except Exception as e:
        print(f"[AUDIT][ERROR] Failed to read {file}: {e}")
        continue

    for line in content.splitlines():
        if "TradingView" in line or "new TradingView" in line:
            print(f"[AUDIT][TV_REF] {file.name}: {line.strip()}")

        if "createChart" in line or "widget" in line:
            print(f"[AUDIT][CHART_API] {file.name}: {line.strip()}")

        if "import" in line and "ChartContainer" in line:
            print(f"[AUDIT][IMPORT] {file.name}: {line.strip()}")

print("[BULK] Phase O-8 — ChartContainer ownership AUDIT (READ-ONLY) COMPLETE")
