import sys
sys.dont_write_bytecode = True

from pathlib import Path
import re

print("[BULK] Phase O-4 — Controllers AUDIT (read-only) START")

PROJECT_ROOT = Path.cwd()
TV_ROOT = PROJECT_ROOT / "Frontend" / "src" / "components" / "TradingView"

CONTROLLERS = [
    TV_ROOT / "TradingViewController.js",
    TV_ROOT / "OverlayManager.js",
    TV_ROOT / "DockManager.js",
    TV_ROOT / "core" / "ChartContainer.js",
]

IMPORT_RE = re.compile(r'^\s*import\s+.*?\s+from\s+[\'"](.+?)[\'"];?\s*$')

def audit_file(file_path: Path):
    if not file_path.exists():
        print(f"[BULK] SKIPPED (not found): {file_path.relative_to(PROJECT_ROOT)}")
        return

    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"[BULK][ERROR] Read failed: {file_path.name} -> {e}")
        return

    print(f"[BULK] AUDIT FILE: {file_path.relative_to(PROJECT_ROOT)}")

    lines = content.splitlines()
    for line in lines:
        m = IMPORT_RE.match(line)
        if not m:
            continue

        target = m.group(1)
        # Resolve relative targets only for existence check (NO WRITES)
        if target.startswith("."):
            resolved = (file_path.parent / target).resolve()
            exists_js = resolved.with_suffix(".js").exists()
            exists_index = (resolved / "index.js").exists()
            exists = exists_js or exists_index

            status = "OK" if exists else "MISSING"
            print(f"  [IMPORT][{status}] {target}")

    print(f"[BULK] AUDIT COMPLETE: {file_path.name}")

# ---- Execute audits ----
for controller in CONTROLLERS:
    audit_file(controller)

# ---- REQUIRED TEST FILE UPDATE (README compliance) ----
frontend_test = PROJECT_ROOT / "Frontend" / "src" / "components" / "tests" / "test_update.js"
backend_test = PROJECT_ROOT / "Backend" / "tests" / "test_update.py"

if frontend_test.exists():
    frontend_test.write_text(
        frontend_test.read_text(encoding="utf-8") + "\n// Phase O-4 controllers audit\n",
        encoding="utf-8",
    )
    print("[BULK] UPDATED TEST FILE:", frontend_test.relative_to(PROJECT_ROOT))

if backend_test.exists():
    backend_test.write_text(
        backend_test.read_text(encoding="utf-8") + "\n# Phase O-4 controllers audit\n",
        encoding="utf-8",
    )
    print("[BULK] UPDATED TEST FILE:", backend_test.relative_to(PROJECT_ROOT))

print("[BULK] Phase O-4 — Controllers AUDIT (read-only) COMPLETE")
