# 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# 🚫 NO PARTIAL FILES | 🚫 NO MICROFIXES | ✅ FULL OVERWRITES ONLY

import os
import sys
sys.dont_write_bytecode = True

BASE = os.path.join(
    "Frontend", "src", "components", "TradingView"
)

FILES = {}

# ---------------------------------------------------------
# ChartContainer.js (SINGLE SOURCE OF TRUTH)
# ---------------------------------------------------------
FILES[os.path.join(BASE, "ChartContainer.js")] = """\
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 SINGLE SOURCE OF TRUTH FOR TRADINGVIEW CONTAINER

import React from "react";
import "./ChartContainer.css";

export const TRADINGVIEW_CONTAINER_ID = "tradingview-chart";

export default function ChartContainer() {
  return (
    <div
      id={TRADINGVIEW_CONTAINER_ID}
      className="tradingview-chart-container"
    />
  );
}
"""

# ---------------------------------------------------------
# TradingViewController.js (NO DOM CREATION)
# ---------------------------------------------------------
FILES[os.path.join(BASE, "TradingViewController.js")] = """\
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 CONTROLLER MUST NEVER CREATE OR GUESS CONTAINER IDS

import { useEffect } from "react";
import { TRADINGVIEW_CONTAINER_ID } from "./ChartContainer";

export default function TradingViewController() {
  useEffect(() => {
    const container = document.getElementById(TRADINGVIEW_CONTAINER_ID);

    if (!container) {
      console.error(
        "[TradingViewController] Container not found:",
        TRADINGVIEW_CONTAINER_ID
      );
      return;
    }

    if (!window.TradingView) {
      console.error("[TradingViewController] TradingView library not loaded");
      return;
    }

    if (container.childNodes.length > 0) return;

    new window.TradingView.widget({
      container_id: TRADINGVIEW_CONTAINER_ID,
      symbol: "BINANCE:BTCUSDT",
      interval: "15",
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1",
      locale: "en",
      autosize: true,
      allow_symbol_change: true,
    });
  }, []);

  return null;
}
"""

# ---------------------------------------------------------
# TradingViewChartSection.js (COMPOSITION ONLY)
# ---------------------------------------------------------
FILES[os.path.join(BASE, "TradingViewChartSection.js")] = """\
// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO DOM LOGIC — COMPOSITION ONLY

import ChartContainer from "./ChartContainer";
import TradingViewController from "./TradingViewController";
import "./TradingViewChartSection.css";

export default function TradingViewChartSection() {
  return (
    <section className="tradingview-section">
      <ChartContainer />
      <TradingViewController />
    </section>
  );
}
"""

# ---------------------------------------------------------
# REQUIRED TEST FILES (ALWAYS UPDATED)
# ---------------------------------------------------------
FILES[os.path.join("Frontend", "src", "components", "tests", "test_update.js")] = """\
console.log("TradingView container contract test executed");
"""

FILES[os.path.join("Backend", "tests", "test_update.py")] = """\
print("TradingView container contract backend test executed")
"""

# ---------------------------------------------------------
# WRITE FILES
# ---------------------------------------------------------
for path, content in FILES.items():
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)

print("[BULK] TradingView container contract applied")
