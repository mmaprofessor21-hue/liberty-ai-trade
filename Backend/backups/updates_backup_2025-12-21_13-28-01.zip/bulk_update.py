#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE = os.path.dirname(__file__)
FILES = {}

def write(path, content):
    full = os.path.join(BASE, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {path}")
    FILES[path] = True


# -------------------------------------------------
# TradingViewController.js
# TradingView STABILIZATION PASS
# - waits for DOM + layout stability
# - prevents empty container init
# - single widget instance only
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewController.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useEffect, useRef } from "react";
import "./TradingViewController.css";

export default function TradingViewController() {
  const chartRef = useRef(null);
  const widgetRef = useRef(null);
  const observerRef = useRef(null);

  useEffect(() => {
    if (!chartRef.current) return;
    if (widgetRef.current) return;

    if (!window.TradingView || !window.TradingView.widget) {
      console.warn("[TradingView] tv.js not loaded yet");
      return;
    }

    const container = chartRef.current;

    const tryInit = () => {
      const width = container.offsetWidth;
      const height = container.offsetHeight;

      if (width === 0 || height === 0) return;
      if (widgetRef.current) return;

      widgetRef.current = new window.TradingView.widget({
        autosize: true,
        symbol: "BINANCE:BTCUSDT",
        interval: "15",
        timezone: "Etc/UTC",
        theme: "dark",
        style: "1",
        locale: "en",
        container: container,
        hide_top_toolbar: true,
        hide_legend: true,
        allow_symbol_change: true,
      });

      if (observerRef.current) {
        observerRef.current.disconnect();
        observerRef.current = null;
      }
    };

    observerRef.current = new ResizeObserver(tryInit);
    observerRef.current.observe(container);

    tryInit();

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
        observerRef.current = null;
      }
    };
  }, []);

  return (
    <div className="tv-panel">
      <div className="tv-panel-inner">
        <div className="tv-chart-shell" ref={chartRef}>
          <div className="tv-placeholder">Loading chart…</div>
        </div>
      </div>
    </div>
  );
}
"""
)


# -------------------------------------------------
# MANDATORY TEST FILES (REQUIRED EVERY RUN)
# -------------------------------------------------
write(
    "Frontend/src/components/tests/test_update.js",
    """// updater test file
export const UPDATE_TEST = "TradingView stabilization pass";
"""
)

write(
    "Backend/tests/test_update.py",
    "# updater test file\nUPDATE_TEST = 'TradingView stabilization pass'\n"
)

print(f"[BULK] Successfully processed {len(FILES)} files")
