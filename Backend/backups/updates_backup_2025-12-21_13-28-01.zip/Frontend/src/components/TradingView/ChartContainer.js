// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React from "react";
import "./ChartContainer.css";

export default function ChartContainer({ containerRef }) {
  return (
    <div className="chart-container">
      <div ref={containerRef} className="chart-inner" />
    </div>
  );
}
