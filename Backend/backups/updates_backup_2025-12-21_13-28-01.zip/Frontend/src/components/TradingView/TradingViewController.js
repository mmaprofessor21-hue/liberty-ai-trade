// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useEffect, useRef } from "react";
import "./TradingViewController.css";

export default function TradingViewController() {
  const chartRef = useRef(null);
  const widgetRef = useRef(null);

  useEffect(() => {
    if (!chartRef.current) return;
    if (widgetRef.current) return;

    if (!window.TradingView || !window.TradingView.widget) {
      console.warn("[TradingView] Widget library not loaded yet");
      return;
    }

    widgetRef.current = new window.TradingView.widget({
      autosize: true,
      symbol: "BINANCE:BTCUSDT",
      interval: "15",
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1",
      locale: "en",
      container: chartRef.current,
      hide_top_toolbar: true,
      hide_legend: true,
      withdateranges: false,
      allow_symbol_change: true,
    });
  }, []);

  return (
    <div className="tv-panel">
      <div className="tv-panel-inner">
        <div className="tv-chart-shell" ref={chartRef}>
          <div className="tv-placeholder">Loading chart...</div>
        </div>
      </div>
    </div>
  );
}
