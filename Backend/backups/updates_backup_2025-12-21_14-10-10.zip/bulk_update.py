#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

DROP_ZONE = os.path.dirname(os.path.abspath(__file__))

def write(rel_path, content):
    abs_path = os.path.join(DROP_ZONE, rel_path.replace("/", os.sep))
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {rel_path}")

def main():
    count = 0

    # -------------------------------------------------
    # TradingViewPanel.css
    # FIX: REMOVE FIXED HEIGHT FROM DOCKED MODE
    # KEEP FLOATING MODE CONTROLLED
    # -------------------------------------------------
    write(
        "Frontend/src/components/TradingView/TradingViewPanel.css",
        """\
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */

/* =========================================================
   TradingView Panel — Height Contract (LOCKED)
   - Docked: ORGANIC HEIGHT (NO CAPS)
   - Floating: CONTROLLED HEIGHT ALLOWED
   ========================================================= */

.tv-container {
  position: relative;
  width: 100%;
  overflow: visible;
}

/* -----------------------------
   DOCKED MODE (PAGE FLOW)
   ----------------------------- */
.tv-container.docked {
  position: relative;
  width: 100%;

  /* CRITICAL: REMOVE ALL HEIGHT CAPS */
  height: auto;
  min-height: unset;
  max-height: unset;

  margin-top: 15px;
  overflow: visible;
}

/* -----------------------------
   FLOATING MODE (WINDOW-LIKE)
   ----------------------------- */
.tv-container.floating {
  position: fixed;
  width: 80%;
  height: 70vh;          /* INTENTIONAL: floating may be constrained */
  min-height: 480px;
  max-height: 90vh;

  top: 10%;
  left: 10%;
  z-index: 1000;
  overflow: hidden;
}

/* Optional visual polish (no layout impact) */
.tv-container.floating .tradingview-chart-container {
  border-radius: 6px;
}
"""
    )
    count += 1

    # -------------------------------------------------
    # MANDATORY UPDATER TEST FILES (ALWAYS UPDATED)
    # -------------------------------------------------
    write(
        "Frontend/src/components/tests/test_update.js",
        """\
console.log("TradingViewPanel docked height constraint removed (test)");
"""
    )
    count += 1

    write(
        "Backend/tests/test_update.py",
        """\
print("TradingViewPanel docked height constraint removed (backend test)")
"""
    )
    count += 1

    print(f"[BULK] Successfully processed {count} files")

if __name__ == "__main__":
    main()
