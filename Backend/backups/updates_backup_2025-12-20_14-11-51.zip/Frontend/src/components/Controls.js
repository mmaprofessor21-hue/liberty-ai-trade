// AUTO-GENERATED VIA BULK UPDATE — CONTROLS LEGACY ENTRY FIX
// DO NOT DEEP-IMPORT SUBCOMPONENTS HERE

import React from "react";
import ControlsPanel from "./Controls/ControlsPanel";

export default function Controls() {
  return <ControlsPanel />;
}
