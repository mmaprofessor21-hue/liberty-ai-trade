/* TIMESTAMP: 2025-12-09_20-12-41 */
import React, { useEffect, useRef } from 'react';
import './TradingViewChartSection.css';
import AISignalOverlay from './AISignalOverlay';

export default function TradingViewChartSection() {

  const chartContainerRef = useRef(null);

  useEffect(() => {
    if (chartContainerRef.current && window.TradingView && window.TradingView.widget) {
      new window.TradingView.widget({
        autosize: true,
        symbol: "BTCUSD",
        interval: "60",
        timezone: "Etc/UTC",
        theme: "dark",
        style: "1",
        locale: "en",
        container_id: chartContainerRef.current.id,
        height: 600,
        width: "100%",
      });
    }
  }, []);

  return (
    <section className="tv-section">

      <div className="tv-dock-toggle">
        <button className="tv-dock-button">Dock / Undock Chart</button>
      </div>

      <AISignalOverlay />

      <div
        id="tv-chart-container"
        ref={chartContainerRef}
        className="tv-chart-container"
      ></div>

    </section>
  );
}
