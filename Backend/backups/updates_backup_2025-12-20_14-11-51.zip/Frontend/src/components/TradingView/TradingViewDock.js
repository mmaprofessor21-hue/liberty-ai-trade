
import React from "react";
import "./TradingViewDock.css";

export default function TradingViewDock({ docked, setDocked }) {
    return (
        <div className="dock-wrapper">
            <button 
                className="dock-btn"
                onClick={() => setDocked(!docked)}
            >
                {docked ? "Undock Chart" : "Dock Chart"}
            </button>
        </div>
    );
}
