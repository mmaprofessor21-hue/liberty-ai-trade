import sys
sys.dont_write_bytecode = True

from pathlib import Path

print("[BULK] Phase O-9 - TradingView ENTRY-POINT AUDIT (READ-ONLY) START")

PROJECT_ROOT = Path(__file__).resolve().parents[2]
FRONTEND_SRC = PROJECT_ROOT / "Frontend" / "src"

# Targets we want to identify as "entry chain" components.
PATTERNS = [
    "TradingViewController",
    "TradingViewPanel",
    "TradingViewWidget",
    "ChartContainer",
    "OverlayManager",
    "DockManager",
    "TradingViewDock",
    "TradingViewSection",
    "TradingViewChartSection",
]

# File types to scan
SCAN_EXTS = {".js", ".jsx", ".ts", ".tsx"}

if not FRONTEND_SRC.exists():
    print("[AUDIT][ERROR] Frontend/src not found:", str(FRONTEND_SRC))
else:
    print("[AUDIT] Scanning:", str(FRONTEND_SRC))
    hits = 0

    try:
        for p in FRONTEND_SRC.rglob("*"):
            if not p.is_file():
                continue
            if p.suffix.lower() not in SCAN_EXTS:
                continue

            try:
                text = p.read_text(encoding="utf-8", errors="ignore")
            except Exception as e:
                print("[AUDIT][ERROR] Read failed:", str(p), "|", str(e))
                continue

            lines = text.splitlines()
            for i, line in enumerate(lines, start=1):
                # Keep output tight: only show meaningful hits
                if "import" in line or "<" in line or "require(" in line:
                    for key in PATTERNS:
                        if key in line:
                            rel = str(p.relative_to(PROJECT_ROOT))
                            print(f"[AUDIT][ENTRY_HIT] {rel}:{i}  {line.strip()}")
                            hits += 1
                            break

        if hits == 0:
            print("[AUDIT][WARN] No entry hits found. TradingView may be mounted indirectly or patterns differ.")
        else:
            print(f"[AUDIT] Entry hits found: {hits}")

    except Exception as e:
        print("[AUDIT][ERROR] Scan failure:", str(e))

# -----------------------------
# REQUIRED TEST FILE UPDATES
# -----------------------------
frontend_test = PROJECT_ROOT / "Frontend" / "src" / "components" / "tests" / "test_update.js"
backend_test = PROJECT_ROOT / "Backend" / "tests" / "test_update.py"

try:
    frontend_test.write_text(
        frontend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n// O-9 TradingView entry-point audit executed\n",
        encoding="utf-8",
    )
    print(f"[BULK] UPDATED TEST FILE: {frontend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Frontend test update failed: {e}")

try:
    backend_test.write_text(
        backend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n# O-9 TradingView entry-point audit executed\n",
        encoding="utf-8",
    )
    print(f"[BULK] UPDATED TEST FILE: {backend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Backend test update failed: {e}")

print("[BULK] Phase O-9 - TradingView ENTRY-POINT AUDIT (READ-ONLY) COMPLETE")
