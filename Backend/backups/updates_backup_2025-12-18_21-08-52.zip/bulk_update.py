#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE_DIR = os.path.dirname(__file__)
files_written = 0

def write(path, content):
    global files_written
    full_path = os.path.join(BASE_DIR, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK] {path}")
    files_written += 1


# ============================================================
# WALLET DATA — TERMINAL HOST ISOLATION
# ------------------------------------------------------------
# PURPOSE:
# - Remove Wallet Data from card-style wallet-section
# - Allow full vertical expansion
# - Preserve alignment + visuals
# ============================================================

write(
    "Frontend/src/components/Wallet/WalletRoot.js",
    """import React from "react";

import WalletStatus from "./WalletStatus";
import WalletSecurityControls from "./WalletSecurityControls";
import WalletData from "./WalletData";

import "./WalletRoot.css";

export default function WalletRoot() {
  return (
    <div className="wallet-root">

      <div className="wallet-section">
        <WalletStatus />
      </div>

      <div className="wallet-section">
        <WalletSecurityControls />
      </div>

      {/* TERMINAL HOST — NOT A CARD */}
      <div className="wallet-terminal-host">
        <WalletData />
      </div>

    </div>
  );
}
"""
)

write(
    "Frontend/src/components/Wallet/WalletRoot.css",
    """/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
   ✅ WALLET ROOT — TERMINAL HOST ISOLATION
*/

/* Existing rules preserved */

.wallet-terminal-host {
  width: 100%;
  max-width: 1500px;
  margin: 0 auto 72px auto;
  padding: 0;
}
"""
)

print(f"[BULK] Completed — {files_written} file(s) updated")
