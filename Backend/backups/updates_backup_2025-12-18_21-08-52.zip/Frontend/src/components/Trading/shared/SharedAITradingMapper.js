
// TIMESTAMP: PART G
// Shared mapper between AI controls and Trading controls
export const SharedAITradingMapper = {
    mapAIStateToTrading(aiState) {
        return {
            sniper: aiState.sniperMode,
            risk: aiState.riskProfile,
            auto: aiState.autoTrade
        };
    },

    mapTradingStateToAI(tradingState) {
        return {
            sniperMode: tradingState.sniper,
            riskProfile: tradingState.risk,
            autoTrade: tradingState.auto
        };
    }
};
