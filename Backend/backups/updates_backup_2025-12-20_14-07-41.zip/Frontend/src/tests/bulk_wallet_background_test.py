def test_wallet_background_not_clipped():
    assert True\n