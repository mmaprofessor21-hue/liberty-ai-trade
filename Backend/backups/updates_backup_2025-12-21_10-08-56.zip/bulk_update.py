# bulk_update.py
# PHASE O-6 — Overlay Import Owner Audit (READ-ONLY)
# DO NOT MOVE / DO NOT RENAME / DO NOT REWRITE SOURCE FILES

import sys
sys.dont_write_bytecode = True

import os
from pathlib import Path

print("[BULK] Phase O-6 — Overlay Import Owner AUDIT (READ-ONLY) START")

PROJECT_ROOT = Path(__file__).resolve().parents[2]
TV_ROOT = PROJECT_ROOT / "Frontend" / "src" / "components" / "TradingView"

OVERLAYS = [
    "AISignalOverlay",
    "AIHeatmapOverlay",
    "AIIndicatorLayer",
    "AITendencyCloud",
    "AISupportResistance",
    "StrategyIndicator",
    "TradingViewMarkers",
    "SentimentMeter",
    "SentimentSourceSelector",
]

SEARCH_AREAS = [
    TV_ROOT / "engines",
    TV_ROOT / "adapters",
    TV_ROOT / "core",
    TV_ROOT,
]

results = {name: [] for name in OVERLAYS}

def safe_read(path: Path):
    try:
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return ""

for area in SEARCH_AREAS:
    if not area.exists():
        continue

    for file in area.rglob("*.js"):
        content = safe_read(file)
        for overlay in OVERLAYS:
            if overlay in content:
                results[overlay].append(str(file.relative_to(TV_ROOT)))

# REPORT
for overlay, owners in results.items():
    if owners:
        for owner in owners:
            print(f"[AUDIT] {overlay} imported by: {owner}")
    else:
        print(f"[AUDIT][ORPHAN] {overlay} not imported anywhere")

# --- REQUIRED TEST FILE TOUCHES (PROOF OF EXECUTION) ---
frontend_test = PROJECT_ROOT / "Frontend" / "src" / "components" / "tests" / "test_update.js"
backend_test = PROJECT_ROOT / "Backend" / "tests" / "test_update.py"

try:
    frontend_test.write_text(
        frontend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n// O-6 overlay import audit executed\n",
        encoding="utf-8"
    )
    print(f"[BULK] UPDATED TEST FILE: {frontend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Failed updating frontend test file: {e}")

try:
    backend_test.write_text(
        backend_test.read_text(encoding="utf-8", errors="ignore")
        + "\n# O-6 overlay import audit executed\n",
        encoding="utf-8"
    )
    print(f"[BULK] UPDATED TEST FILE: {backend_test}")
except Exception as e:
    print(f"[BULK][ERROR] Failed updating backend test file: {e}")

print("[BULK] Phase O-6 — Overlay Import Owner AUDIT COMPLETE")
