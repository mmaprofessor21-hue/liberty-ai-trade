// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE
/* TIMESTAMP PLACEHOLDER */

import React from "react";
import "./TradingViewFloating.css";

export default function TradingViewFloating({ children }) {
    return (
        <div className="tv-floating-window">
            <div className="tv-floating-header">TRADINGVIEW (FLOATING)</div>
            <div className="tv-floating-body">
                {children}
            </div>
        </div>
    );
}
