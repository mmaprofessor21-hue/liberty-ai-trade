# bulk_update.py
# STRICT BULK — AI OVERLAYS IMPORT REWIRING (PHASE O-1)
# NO LOGIC OUTSIDE BULK
# UTF-8 SAFE
# DO NOT ADD ANY OTHER OPERATIONS

import sys
sys.dont_write_bytecode = True

from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "Frontend" / "src" / "components" / "TradingView"

AI_OVERLAYS = FRONTEND / "overlays" / "ai"

FILES = [
    AI_OVERLAYS / "AIHeatmapOverlay.js",
    AI_OVERLAYS / "AIIndicatorLayer.js",
    AI_OVERLAYS / "AITendencyCloud.js",
    AI_OVERLAYS / "AISupportResistance.js",
    AI_OVERLAYS / "AIExplanationPanel.js",
]

print("[BULK] Phase O-1 — AI overlays import rewiring START")

for file in FILES:
    if not file.exists():
        print(f"[BULK] SKIPPED (missing): {file.relative_to(ROOT)}")
        continue

    try:
        original = file.read_text(encoding="utf-8")
        updated = original

        # ---- SAFE, TARGETED REWRITES ONLY ----
        updated = updated.replace(
            "from './AIPredictionEngine'",
            "from '../../engines/AIPredictionEngine'"
        )

        updated = updated.replace(
            "from './AIOverlayEngine'",
            "from '../../engines/AIOverlayEngine'"
        )

        updated = updated.replace(
            "from '../ChartContainer'",
            "from '../../core/ChartContainer'"
        )

        if updated != original:
            file.write_text(updated, encoding="utf-8")
            print(f"[BULK] UPDATED: {file.relative_to(ROOT)}")
        else:
            print(f"[BULK] NO CHANGE: {file.relative_to(ROOT)}")

    except UnicodeDecodeError:
        print(f"[BULK ERROR] UTF-8 decode failed: {file.relative_to(ROOT)}")

# ---- REQUIRED TEST FILE TOUCH ----
TEST_FRONTEND = ROOT / "Frontend" / "src" / "components" / "tests" / "test_update.js"
TEST_BACKEND = ROOT / "Backend" / "tests" / "test_update.py"

if TEST_FRONTEND.exists():
    TEST_FRONTEND.write_text(
        TEST_FRONTEND.read_text(encoding="utf-8") + "\n// test touch O-1\n",
        encoding="utf-8"
    )
    print(f"[BULK] UPDATED TEST FILE: {TEST_FRONTEND.relative_to(ROOT)}")

if TEST_BACKEND.exists():
    TEST_BACKEND.write_text(
        TEST_BACKEND.read_text(encoding="utf-8") + "\n# test touch O-1\n",
        encoding="utf-8"
    )
    print(f"[BULK] UPDATED TEST FILE: {TEST_BACKEND.relative_to(ROOT)}")

print("[BULK] Phase O-1 — AI overlays import rewiring COMPLETE")
