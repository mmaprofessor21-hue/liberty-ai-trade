#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os
import shutil

# DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

BASE = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "TradingView"
)

OVERLAYS_DIR = os.path.join(BASE, "overlays")
AI_DIR = os.path.join(OVERLAYS_DIR, "ai")
INDICATORS_DIR = os.path.join(OVERLAYS_DIR, "indicators")
SENTIMENT_DIR = os.path.join(OVERLAYS_DIR, "sentiment")

AI_OVERLAYS = [
    "AISignalOverlay.js",
    "AIHeatmapOverlay.js",
    "AIIndicatorLayer.js",
    "AITendencyCloud.js",
    "AISupportResistance.js",
    "AIExplanationPanel.js",
    "AIExplanationPanel.css",
]

INDICATOR_OVERLAYS = [
    "StrategyIndicator.js",
    "StrategyIndicator.css",
    "TradingViewMarkers.js",
    "TradingViewMarkers.css",
]

SENTIMENT_OVERLAYS = [
    "SentimentMeter.js",
    "SentimentMeter.css",
    "SentimentSourceSelector.js",
    "SentimentSourceSelector.css",
]

print("[BULK] TradingView overlays migration START")

# Ensure folders exist
os.makedirs(AI_DIR, exist_ok=True)
os.makedirs(INDICATORS_DIR, exist_ok=True)
os.makedirs(SENTIMENT_DIR, exist_ok=True)

print("[BULK] CREATED FOLDER: TradingView/overlays/ai")
print("[BULK] CREATED FOLDER: TradingView/overlays/indicators")
print("[BULK] CREATED FOLDER: TradingView/overlays/sentiment")

def move_files(file_list, target_dir):
    for fname in file_list:
        src = os.path.join(BASE, fname)
        dst = os.path.join(target_dir, fname)

        if os.path.exists(src):
            shutil.move(src, dst)
            print(
                "[BULK] MOVED FILE: Frontend/src/components/TradingView/"
                + fname
                + " -> "
                + os.path.relpath(dst, BASE)
            )
        else:
            print("[BULK] SKIPPED (not found): TradingView/" + fname)

move_files(AI_OVERLAYS, AI_DIR)
move_files(INDICATOR_OVERLAYS, INDICATORS_DIR)
move_files(SENTIMENT_OVERLAYS, SENTIMENT_DIR)

# ------------------------------------------------------------
# MANDATORY UPDATER TEST FILES (REQUIRED EVERY RUN)
# ------------------------------------------------------------

frontend_test_path = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "tests",
    "test_update.js"
)

backend_test_path = os.path.join(
    "update_engine",
    "updates",
    "Backend",
    "tests",
    "test_update.py"
)

os.makedirs(os.path.dirname(frontend_test_path), exist_ok=True)
os.makedirs(os.path.dirname(backend_test_path), exist_ok=True)

with open(frontend_test_path, "w", encoding="utf-8") as f:
    f.write(
        "// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt\n"
        "// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE\n\n"
        "export default function testUpdate() {\n"
        "  return 'frontend updater test';\n"
        "}\n"
    )

print("[BULK] UPDATED TEST FILE: Frontend/src/components/tests/test_update.js")

with open(backend_test_path, "w", encoding="utf-8") as f:
    f.write(
        "# DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt\n"
        "# NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE\n\n"
        "def test_update():\n"
        "    return 'backend updater test'\n"
    )

print("[BULK] UPDATED TEST FILE: Backend/tests/test_update.py")

print("[BULK] TradingView overlays migration COMPLETE")
