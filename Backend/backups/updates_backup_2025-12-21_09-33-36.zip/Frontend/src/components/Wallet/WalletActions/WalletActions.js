// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt

import React from "react";

export default function WalletActions() {
  return (
    <div className="wallet-actions">
      <button>DEPOSIT</button>
      <button>WITHDRAW</button>
    </div>
  );
}
