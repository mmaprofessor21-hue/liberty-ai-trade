#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

DROP_ZONE = os.path.dirname(os.path.abspath(__file__))

def write(rel_path, content):
    abs_path = os.path.join(DROP_ZONE, rel_path.replace("/", os.sep))
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {rel_path}")

def main():
    count = 0

    # -------------------------------------------------
    # TradingViewChartSection.css
    # REMOVE ALL VERTICAL RESTRICTIONS
    # -------------------------------------------------
    write(
        "Frontend/src/components/TradingView/TradingViewChartSection.css",
        """\
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO HEIGHT CAPS | 🚫 NO FLEX LOCKS | ✅ ORGANIC FLOW */

.tradingview-section {
  width: 100%;
  position: relative;

  /* CRITICAL: allow TradingView to control height */
  height: auto;
  min-height: unset;
  max-height: unset;

  display: block;
  overflow: visible;
}
"""
    )
    count += 1

    # -------------------------------------------------
    # ChartContainer.css
    # REMOVE ALL HEIGHT / FLEX CONSTRAINTS
    # -------------------------------------------------
    write(
        "Frontend/src/components/TradingView/ChartContainer.css",
        """\
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO VERTICAL CONSTRAINTS — TRADINGVIEW AUTOSIZE OWNS HEIGHT */

.tradingview-chart-container {
  width: 100%;
  position: relative;

  /* LET THE WIDGET DECIDE */
  height: auto;
  min-height: unset;
  max-height: unset;

  overflow: visible;
}
"""
    )
    count += 1

    # -------------------------------------------------
    # MANDATORY TEST FILES (ALWAYS UPDATED)
    # -------------------------------------------------
    write(
        "Frontend/src/components/tests/test_update.js",
        """\
console.log("TradingView vertical constraint removal test executed");
"""
    )
    count += 1

    write(
        "Backend/tests/test_update.py",
        """\
print("TradingView vertical constraint removal backend test executed")
"""
    )
    count += 1

    print(f"[BULK] Successfully processed {count} files")

if __name__ == "__main__":
    main()
