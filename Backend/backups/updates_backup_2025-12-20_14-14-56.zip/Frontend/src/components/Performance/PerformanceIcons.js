// DO NOT MODIFY OUTSIDE README_UPDATER RULES
/* TIMESTAMP: */

const icons = {
  pnlUsd: "💲",
  pnlSol: "🪙",
  winRate: "🏆",
  totalTrades: "📊",
  lastProfit: "💹",
  uptime: "⏱",
  tps: "🚀",
  strategy: "♞",
  risk: "⚠️",
  sentiment: "📈",
  aiConfidence: "🧠"
};

export default icons;
