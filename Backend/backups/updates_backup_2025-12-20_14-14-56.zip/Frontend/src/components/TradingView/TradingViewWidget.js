// TIMESTAMP
// DO NOT MODIFY OUTSIDE UPDATE PIPELINE
import React, { useEffect, useRef } from "react";

const TradingViewWidget = () => {
  const containerRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const script = document.createElement("script");
    script.src = "https://s3.tradingview.com/tv.js";
    script.async = true;

    script.onload = () => {
      if (window.TradingView && containerRef.current) {
        try {
          // eslint-disable-next-line no-new
          new window.TradingView.widget({
            autosize: true,
            symbol: "BTCUSD",
            interval: "1",
            timezone: "Etc/UTC",
            theme: "dark",
            style: "1",
            locale: "en",
            toolbar_bg: "#000000",
            enable_publishing: false,
            container_id: containerRef.current.id || "tv_chart_container",
          });
        } catch (err) {
          // eslint-disable-next-line no-console
          console.error("TradingView widget init failed:", err);
        }
      }
    };

    containerRef.current.appendChild(script);

    return () => {
      if (containerRef.current && script.parentNode === containerRef.current) {
        containerRef.current.removeChild(script);
      }
    };
  }, []);

  return (
    <div className="tv-widget-container">
      <div
        id="tv_chart_container"
        ref={containerRef}
        className="tv-widget-inner"
      />
    </div>
  );
};

export default TradingViewWidget;
