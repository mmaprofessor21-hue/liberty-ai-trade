#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

# bulk_update.py
# NOTE: This script writes ONLY into the staged updates subtree next to this file.
# It MUST print [BULK] lines for every file written, and a final success count.

import os
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def _now_stamp():
    # Core may inject/normalize timestamps later; we keep a stable ASCII stamp here.
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

def write_text_file(rel_path, content):
    # Enforce relative-only writes under the updater drop zone
    rel_path = rel_path.replace("\\", "/").lstrip("/")
    abs_path = os.path.join(BASE_DIR, rel_path)

    os.makedirs(os.path.dirname(abs_path), exist_ok=True)

    # Always write UTF-8. If any downstream read fails, core must log without halting.
    with open(abs_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(content)

    print(f"[BULK]   {rel_path}")
    return 1

def main():
    count = 0
    ts = _now_stamp()

    # -------------------------------------------------------------------------
    # TradingView container contract: remove vertical caps, allow organic height,
    # ensure widget/iframe can fill available space.
    # -------------------------------------------------------------------------

    count += write_text_file(
        "Frontend/src/components/TradingView/TradingViewPanel.css",
        f"""/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */
/* TIMESTAMP: {ts} */

/* TradingViewPanel.css
   Contract:
   - No hard height caps that collapse the TradingView widget
   - Container grows organically with layout
   - Inner chart area gets a usable min-height and flex fill
*/

.tv-panel-wrapper {{
  width: 100%;
}}

.tv-ai-controls-wrapper {{
  margin-bottom: 15px;
}}

/* IMPORTANT: remove fixed height caps */
.tv-container.docked {{
  position: relative;
  width: 100%;
  height: auto;
  min-height: 520px;
  margin-top: 15px;
  display: flex;
  flex-direction: column;
}}

.tv-container.floating {{
  position: fixed;
  z-index: 9999;
  width: 70vw;
  height: 60vh;
  min-width: 720px;
  min-height: 520px;
  max-width: 95vw;
  max-height: 90vh;
  display: flex;
  flex-direction: column;
}}

/* Outer panel shell (kept minimal to avoid regressions) */
.tv-panel {{
  width: 100%;
  padding: 12px 0 0;
}}

.tv-panel-inner {{
  border-radius: 24px;
  padding: 18px 24px 24px;
}}

/* The chart shell must be allowed to fill available height */
.tv-chart-shell {{
  position: relative;
  width: 100%;
  flex: 1 1 auto;
  min-height: 520px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}}

/* Widget host should fill the chart shell */
.tv-widget-container {{
  position: relative;
  width: 100%;
  flex: 1 1 auto;
  min-height: 520px;
  overflow: hidden;
}}

.tv-widget-inner {{
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}}

/* Optional overlay chips (kept from existing UI expectations) */
.tv-chip-long {{
  border-color: rgba(34, 197, 94, 0.8);
  color: rgba(34, 197, 94, 0.95);
}}

.tv-chip-short {{
  border-color: rgba(248, 113, 113, 0.8);
  color: rgba(248, 113, 113, 0.95);
}}

.tv-overlay-metric {{
  opacity: 0.9;
}}
"""
    )

    count += write_text_file(
        "Frontend/src/components/TradingView/TradingViewChartSection.css",
        f"""/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */
/* TIMESTAMP: {ts} */

/* TradingViewChartSection.css
   Contract:
   - No vertical restrictions that collapse the TradingView widget
   - Section stacks controls + chart naturally
*/

.tv-section {{
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}}

.tv-dock-toggle {{
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 0.5rem;
}}

/* Ensure the chart area can grow */
.tv-section .tv-container,
.tv-section .tv-container.docked,
.tv-section .tv-chart-shell,
.tv-section .tv-widget-container {{
  flex: 1 1 auto;
  height: auto;
  min-height: 520px;
}}
"""
    )

    count += write_text_file(
        "Frontend/src/components/TradingView/ChartContainer.css",
        f"""/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */
/* TIMESTAMP: {ts} */

/* ChartContainer.css
   Contract:
   - Host must allow embedded TradingView iframe/widget to fill space
*/

.tv-chart-container {{
  position: relative;
  width: 100%;
  height: 100%;
  min-height: 520px;
  overflow: hidden;
}}

.tv-chart-embed {{
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  border: 0;
}}
"""
    )

    # -------------------------------------------------------------------------
    # REQUIRED TEST FILES (must update every run)
    # -------------------------------------------------------------------------

    count += write_text_file(
        "Frontend/src/components/tests/test_update.js",
        f"""// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE
// TIMESTAMP: {ts}

export default function test_update() {{
  return "test_update_frontend_ok_{ts}";
}}
"""
    )

    count += write_text_file(
        "Backend/tests/test_update.py",
        f"""# 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE
# TIMESTAMP: {ts}

def test_update():
    return "test_update_backend_ok_{ts}"
"""
    )

    print(f"[BULK] Successfully processed {count} files")

if __name__ == "__main__":
    main()
