test("WalletRoot mounts with background ownership", () => {
  expect(true).toBe(true);
});
