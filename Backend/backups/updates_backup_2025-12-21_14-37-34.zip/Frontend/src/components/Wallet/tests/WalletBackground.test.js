test("Wallet background spans full wallet height", () => {
  expect(true).toBe(true);
});
