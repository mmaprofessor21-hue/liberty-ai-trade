#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

# 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
# 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

BASE = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "TradingView"
)

FOLDERS = [
    "core",
    "overlays",
    os.path.join("overlays", "ai"),
    os.path.join("overlays", "indicators"),
    os.path.join("overlays", "drawings"),
    "adapters",
    "utils",
    "experiments",
]

print("[BULK] TradingView folder initialization START")

for folder in FOLDERS:
    path = os.path.join(BASE, folder)
    os.makedirs(path, exist_ok=True)
    print(f"[BULK] CREATED FOLDER → Frontend/src/components/TradingView/{folder}")

# ------------------------------------------------------------
# MANDATORY UPDATER TEST FILES (REQUIRED EVERY RUN)
# ------------------------------------------------------------

frontend_test_path = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "tests",
    "test_update.js"
)

backend_test_path = os.path.join(
    "update_engine",
    "updates",
    "Backend",
    "tests",
    "test_update.py"
)

os.makedirs(os.path.dirname(frontend_test_path), exist_ok=True)
os.makedirs(os.path.dirname(backend_test_path), exist_ok=True)

with open(frontend_test_path, "w", encoding="utf-8") as f:
    f.write(
        "// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt\n"
        "// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE\n\n"
        "export default function testUpdate() {\n"
        "  return 'frontend updater test';\n"
        "}\n"
    )

print("[BULK] UPDATED TEST FILE → Frontend/src/components/tests/test_update.js")

with open(backend_test_path, "w", encoding="utf-8") as f:
    f.write(
        "# 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt\n"
        "# 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE\n\n"
        "def test_update():\n"
        "    return 'backend updater test'\n"
    )

print("[BULK] UPDATED TEST FILE → Backend/tests/test_update.py")

print("[BULK] TradingView folder initialization COMPLETE")
