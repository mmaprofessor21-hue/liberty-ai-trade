#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os
import re

# DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER.txt
# ABSOLUTE STRUCTURE COMPLIANCE

BASE = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "TradingView"
)

CORE_FILES = [
    "TradingViewController.js",
    "OverlayManager.js",
    "DockManager.js",
    "core/ChartContainer.js",
]

REPLACEMENTS = {
    r'from "./AIPredictionEngine"': 'from "./engines/AIPredictionEngine"',
    r'from "./AIOverlayEngine"': 'from "./engines/AIOverlayEngine"',
    r'from "./AIExplanationEngine"': 'from "./engines/AIExplanationEngine"',
    r'from "./StrategyRouter"': 'from "./engines/StrategyRouter"',

    r'from "./TokenRouter"': 'from "./adapters/TokenRouter"',
    r'from "./SymbolParser"': 'from "./adapters/SymbolParser"',
    r'from "./SymbolDetector"': 'from "./adapters/SymbolDetector"',

    r'from "./AISupportResistance"': 'from "./overlays/ai/AISupportResistance"',
    r'from "./AIHeatmapOverlay"': 'from "./overlays/ai/AIHeatmapOverlay"',
    r'from "./AIIndicatorLayer"': 'from "./overlays/ai/AIIndicatorLayer"',
    r'from "./AITendencyCloud"': 'from "./overlays/ai/AITendencyCloud"',

    r'from "./StrategyIndicator"': 'from "./overlays/indicators/StrategyIndicator"',
    r'from "./TradingViewMarkers"': 'from "./overlays/indicators/TradingViewMarkers"',

    r'from "./SentimentMeter"': 'from "./overlays/sentiment/SentimentMeter"',
    r'from "./SentimentSourceSelector"': 'from "./overlays/sentiment/SentimentSourceSelector"',
}

print("[BULK] TradingView core import rewiring START")

for rel_path in CORE_FILES:
    file_path = os.path.join(BASE, rel_path)

    if not os.path.exists(file_path):
        print("[BULK] SKIPPED (not found): TradingView/" + rel_path)
        continue

    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()

    original = content

    for pattern, replacement in REPLACEMENTS.items():
        content = re.sub(pattern, replacement, content)

    if content != original:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
        print("[BULK] UPDATED IMPORTS:", "TradingView/" + rel_path)
    else:
        print("[BULK] NO CHANGE:", "TradingView/" + rel_path)

# ------------------------------------------------------------
# REQUIRED TEST FILES
# ------------------------------------------------------------

frontend_test = os.path.join(
    "update_engine",
    "updates",
    "Frontend",
    "src",
    "components",
    "tests",
    "test_update.js"
)

backend_test = os.path.join(
    "update_engine",
    "updates",
    "Backend",
    "tests",
    "test_update.py"
)

os.makedirs(os.path.dirname(frontend_test), exist_ok=True)
os.makedirs(os.path.dirname(backend_test), exist_ok=True)

with open(frontend_test, "w", encoding="utf-8") as f:
    f.write("export default () => 'frontend import rewire test';\n")

with open(backend_test, "w", encoding="utf-8") as f:
    f.write("def test_update(): return 'backend import rewire test'\n")

print("[BULK] TradingView core import rewiring COMPLETE")
