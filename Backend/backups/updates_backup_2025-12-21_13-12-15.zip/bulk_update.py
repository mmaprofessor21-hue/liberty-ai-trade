#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE = os.path.dirname(__file__)
FILES = {}

def write(path, content):
    full = os.path.join(BASE, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {path}")
    FILES[path] = True


# -------------------------------------------------
# core/ChartContainer.js
# FULL FILE — legacy TradingView execution REMOVED
# This file is now PASSIVE by design
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/core/ChartContainer.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React from "react";

// NOTE:
// This file previously contained TradingView widget logic.
// That responsibility has been moved to TradingViewController.
//
// This container is now a PASSIVE layout helper only.
// It must NOT instantiate TradingView or touch the DOM directly.

export default function CoreChartContainer({ children }) {
  return (
    <div className="tv-core-chart-container">
      {children}
    </div>
  );
}
"""
)


# -------------------------------------------------
# MANDATORY TEST FILES (REQUIRED EVERY RUN)
# -------------------------------------------------
write(
    "Frontend/src/components/tests/test_update.js",
    """// updater test file
export const UPDATE_TEST = "Core ChartContainer TradingView execution removed";
"""
)

write(
    "Backend/tests/test_update.py",
    "# updater test file\nUPDATE_TEST = 'Core ChartContainer TradingView execution removed'\n"
)

print(f"[BULK] Successfully processed {len(FILES)} files")
