# updater test file
UPDATE_TEST = 'TradingViewWidget auto-execution removed'
