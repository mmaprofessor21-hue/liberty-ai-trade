# 🚨 BULK UPDATE FILE — READ-ONLY AUDIT
# 🚫 NO FILE MOVES
# 🚫 NO RENAMES
# 🚫 NO IMPORT REWRITES
# ✅ TERMINAL VISIBILITY REQUIRED
# ✅ TEST FILES UPDATED (PROOF OF EXECUTION)

import sys
import os

sys.dont_write_bytecode = True

print("[BULK] Phase O-5 — OverlayManager dependency AUDIT (READ-ONLY) START")

PROJECT_ROOT = os.getcwd()
OVERLAY_MANAGER_PATH = os.path.join(
    PROJECT_ROOT,
    "Frontend",
    "src",
    "components",
    "TradingView",
    "OverlayManager.js"
)

OVERLAY_BASE = os.path.join(
    PROJECT_ROOT,
    "Frontend",
    "src",
    "components",
    "TradingView",
    "overlays"
)

def audit_overlay_manager():
    if not os.path.exists(OVERLAY_MANAGER_PATH):
        print(f"[AUDIT][ERROR] OverlayManager not found: {OVERLAY_MANAGER_PATH}")
        return

    print(f"[AUDIT] Reading: {OVERLAY_MANAGER_PATH}")

    with open(OVERLAY_MANAGER_PATH, "r", encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    imports = []
    for line in lines:
        line = line.strip()
        if line.startswith("import ") and "overlays" in line:
            imports.append(line)

    if not imports:
        print("[AUDIT][WARN] No overlay imports detected in OverlayManager")
        return

    print("[AUDIT] Detected overlay imports:")
    for imp in imports:
        print(f"  [IMPORT] {imp}")

    print("[AUDIT] Verifying overlay file existence...")
    for imp in imports:
        parts = imp.split("from")
        if len(parts) < 2:
            continue

        path = parts[1].strip().strip(";").strip("'").strip('"')
        abs_path = os.path.normpath(os.path.join(
            os.path.dirname(OVERLAY_MANAGER_PATH),
            path
        ))

        if os.path.exists(abs_path):
            print(f"  [OK] {abs_path}")
        else:
            print(f"  [MISSING] {abs_path}")

audit_overlay_manager()

# ---- REQUIRED TEST FILE TOUCH (UPDATER VERIFICATION) ----

frontend_test = os.path.join(
    PROJECT_ROOT,
    "Frontend",
    "src",
    "components",
    "tests",
    "test_update.js"
)

backend_test = os.path.join(
    PROJECT_ROOT,
    "Backend",
    "tests",
    "test_update.py"
)

def touch_test_file(path, label):
    try:
        with open(path, "a", encoding="utf-8", errors="ignore") as f:
            f.write(f"\n# BULK O-5 AUDIT CONFIRMATION: {label}\n")
        print(f"[BULK] UPDATED TEST FILE: {path}")
    except Exception as e:
        print(f"[BULK][ERROR] Could not update test file {path}: {e}")

touch_test_file(frontend_test, "Frontend")
touch_test_file(backend_test, "Backend")

print("[BULK] Phase O-5 — OverlayManager dependency AUDIT COMPLETE")
