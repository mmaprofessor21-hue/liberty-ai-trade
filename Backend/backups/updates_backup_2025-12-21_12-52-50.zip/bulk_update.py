#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE = os.path.dirname(__file__)
FILES = {}

def write(path, content):
    full = os.path.join(BASE, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {path}")
    FILES[path] = True


# -------------------------------------------------
# TradingViewController.js
# FULL FILE — React-safe widget initialization
# All layout and intent preserved
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewController.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useEffect, useRef } from "react";
import "./TradingViewController.css";

export default function TradingViewController() {
  const chartRef = useRef(null);
  const widgetRef = useRef(null);

  useEffect(() => {
    if (!chartRef.current) return;
    if (widgetRef.current) return;

    if (!window.TradingView || !window.TradingView.widget) {
      console.warn("[TradingView] Widget library not loaded yet");
      return;
    }

    widgetRef.current = new window.TradingView.widget({
      autosize: true,
      symbol: "BINANCE:BTCUSDT",
      interval: "15",
      timezone: "Etc/UTC",
      theme: "dark",
      style: "1",
      locale: "en",
      container: chartRef.current,
      hide_top_toolbar: true,
      hide_legend: true,
      withdateranges: false,
      allow_symbol_change: true,
    });
  }, []);

  return (
    <div className="tv-panel">
      <div className="tv-panel-inner">
        <div className="tv-chart-shell" ref={chartRef}>
          <div className="tv-placeholder">Loading chart...</div>
        </div>
      </div>
    </div>
  );
}
"""
)


# -------------------------------------------------
# MANDATORY TEST FILES (REQUIRED EVERY RUN)
# -------------------------------------------------
write(
    "Frontend/src/components/tests/test_update.js",
    """// updater test file
export const UPDATE_TEST = "TradingViewController DOM-safe initialization";
"""
)

write(
    "Backend/tests/test_update.py",
    "# updater test file\nUPDATE_TEST = 'TradingViewController DOM-safe initialization'\n"
)

print(f"[BULK] Successfully processed {len(FILES)} files")
