# updater test file
UPDATE_TEST = 'TradingViewChartSection stale import removal'
