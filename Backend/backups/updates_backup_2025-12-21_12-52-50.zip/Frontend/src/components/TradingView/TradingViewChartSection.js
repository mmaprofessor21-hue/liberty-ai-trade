// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useState } from "react";
import "./TradingViewChartSection.css";

import TradingViewController from "./TradingViewController";

export default function TradingViewChartSection() {
  const [isDocked, setIsDocked] = useState(true);

  return (
    <div className="tv-section">
      <div className="tv-dock-toggle">
        <button
          className="tv-dock-button"
          onClick={() => setIsDocked(!isDocked)}
        >
          {isDocked ? "Undock Chart" : "Dock Chart"}
        </button>
      </div>

      <div className="tv-chart-container">
        <TradingViewController />
      </div>
    </div>
  );
}
