// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useEffect, useRef, useState } from "react";
import ChartContainer from "./ChartContainer";
import TradingViewWidget from "./TradingViewWidget";
import TradingViewDock from "./TradingViewDock";

export default function TradingViewController() {
  const containerRef = useRef(null);
  const widgetRef = useRef(null);
  const [symbol, setSymbol] = useState("BINANCE:BTCUSDT");

  useEffect(() => {
    if (!containerRef.current) return;

    if (widgetRef.current) {
      widgetRef.current.remove();
      widgetRef.current = null;
    }

    widgetRef.current = TradingViewWidget({
      container: containerRef.current,
      symbol,
    });

    return () => {
      if (widgetRef.current) {
        widgetRef.current.remove();
        widgetRef.current = null;
      }
    };
  }, [symbol]);

  return (
    <TradingViewDock>
      <div className="tradingview-search">
        <input
          type="text"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          placeholder="EXCHANGE:SYMBOL"
        />
      </div>

      <ChartContainer containerRef={containerRef} />
    </TradingViewDock>
  );
}
