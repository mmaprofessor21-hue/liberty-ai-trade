# P25-06-04_14-47-51
def execute_trade(token: str, amount: float, action: str):
    print(f"Executing {action} of {amount} {token}")
