// 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE

import { useEffect } from "react";
import { TRADINGVIEW_CONTAINER_ID } from "./ChartContainer";

export default function TradingViewController() {
  useEffect(() => {
    const id = TRADINGVIEW_CONTAINER_ID;

    if (!id || typeof id !== "string" || id.trim().length === 0) {
      console.error("[TradingViewController] Invalid container id:", id);
      return;
    }

    const container = document.getElementById(id);
    if (!container) {
      console.error("[TradingViewController] Container not found:", id);
      return;
    }

    // Avoid double-mount if widget already rendered children
    if (container.childNodes && container.childNodes.length > 0) return;

    // Do not assume any extra files exist. Only proceed if TradingView is available.
    if (!window || !window.TradingView || !window.TradingView.widget) {
      // Keep UI stable; do not throw. This prevents SES_UNCAUGHT_EXCEPTION cascades.
      console.warn("[TradingViewController] TradingView.widget not available on window yet");
      return;
    }

    try {
      new window.TradingView.widget({
        container_id: id,
        symbol: "BINANCE:BTCUSDT",
        interval: "15",
        timezone: "Etc/UTC",
        theme: "dark",
        style: "1",
        locale: "en",
        autosize: true,
        allow_symbol_change: true
      });
    } catch (e) {
      console.error("[TradingViewController] Failed to initialize widget:", e);
    }
  }, []);

  return null;
}
