#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE_DIR = os.path.dirname(__file__)
files_written = 0

def write(path, content):
    global files_written
    full_path = os.path.join(BASE_DIR, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK] {path}")
    files_written += 1


# ============================================================
# WALLET ADAPTER INTERFACE (NO IMPLEMENTATION)
# ------------------------------------------------------------
# PURPOSE:
# - Single backend-facing contract for Wallet
# - UI remains untouched
# - Mock or real backend can implement this later
#
# RULES:
# - NO side effects
# - NO imports into UI yet
# - NO logic execution
# ============================================================

write(
    "Frontend/src/components/Wallet/adapters/walletAdapter.interface.js",
    """/**
 * WALLET ADAPTER INTERFACE
 * ------------------------------------------------------------
 * This file defines the REQUIRED contract for any wallet backend.
 * UI components must never talk to the backend directly.
 *
 * Implementation examples:
 * - Solana RPC
 * - Phantom provider
 * - Mock adapter (for dev / tests)
 * ------------------------------------------------------------
 */

export const walletAdapterInterface = {
  // Connection lifecycle
  connect: async () => {
    throw new Error("walletAdapter.connect() not implemented");
  },

  disconnect: async () => {
    throw new Error("walletAdapter.disconnect() not implemented");
  },

  // Wallet identity
  getAddress: async () => {
    throw new Error("walletAdapter.getAddress() not implemented");
  },

  getNetwork: async () => {
    throw new Error("walletAdapter.getNetwork() not implemented");
  },

  // Account data
  getBalance: async () => {
    throw new Error("walletAdapter.getBalance() not implemented");
  },

  // Security / health
  getSecurityStatus: async () => {
    // Expected return shape:
    // { safe: boolean, reason?: string }
    throw new Error("walletAdapter.getSecurityStatus() not implemented");
  },

  // Funds
  requestDeposit: async () => {
    throw new Error("walletAdapter.requestDeposit() not implemented");
  },

  requestWithdraw: async () => {
    throw new Error("walletAdapter.requestWithdraw() not implemented");
  },

  // Data feeds
  getHoldings: async () => {
    throw new Error("walletAdapter.getHoldings() not implemented");
  },

  getTransactionHistory: async () => {
    throw new Error("walletAdapter.getTransactionHistory() not implemented");
  },

  // Optional live channel
  subscribe: (callback) => {
    // callback(payload)
    // return unsubscribe()
    throw new Error("walletAdapter.subscribe() not implemented");
  }
};
"""
)

print(f"[BULK] Completed — {files_written} file(s) added")
