import React from "react";

import WalletStatus from "./WalletStatus";
import WalletSecurityControls from "./WalletSecurityControls";
import WalletData from "./WalletData";

import "./WalletRoot.css";

export default function WalletRoot() {
  return (
    <div className="wallet-root">

      <div className="wallet-section">
        <WalletStatus />
      </div>

      <div className="wallet-section">
        <WalletSecurityControls />
      </div>

      {/* TERMINAL HOST — NOT A CARD */}
      <div className="wallet-terminal-host">
        <WalletData />
      </div>

    </div>
  );
}
