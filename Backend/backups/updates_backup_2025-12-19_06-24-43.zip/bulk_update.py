#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE_DIR = os.path.dirname(__file__)
files_written = 0

def write(path, content):
    global files_written
    full_path = os.path.join(BASE_DIR, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK] {path}")
    files_written += 1


# ============================================================
# WALLET — ZERO VERTICAL CONSTRAINT ENFORCEMENT
# ------------------------------------------------------------
# PURPOSE:
# - Remove ALL artificial vertical envelopes
# - Guarantee content-driven height forever
# - Preserve visuals and layout intent
# ============================================================


# ------------------------------------------------------------
# WalletRoot.css
# ------------------------------------------------------------
write(
    "Frontend/src/components/Wallet/WalletRoot.css",
    """/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER RULES
   ✅ WALLET ROOT — UNCONSTRAINED VERTICAL FLOW
*/

.wallet-root {
  position: relative;
  width: 100%;

  /* BACKGROUND ONLY — MUST GROW WITH CONTENT */
  background-repeat: no-repeat;
  background-position: center top;
  background-size: cover;

  /* 🚫 NO VERTICAL ENVELOPE */
  padding-top: 0 !important;
  padding-bottom: 0 !important;

  height: auto !important;
  min-height: 0 !important;
  max-height: none !important;

  overflow: visible;
}

/* Section spacing is decorative only */
.wallet-section {
  height: auto !important;
  min-height: 0 !important;
  max-height: none !important;
}
"""
)


# ------------------------------------------------------------
# WalletControls.css
# ------------------------------------------------------------
write(
    "Frontend/src/components/Wallet/WalletControls.css",
    """/* WALLET CONTROLS — VERTICAL SAFE */

.wallet-section {
  height: auto !important;
  min-height: 0 !important;
  max-height: none !important;
  overflow: visible;
}
"""
)


# ------------------------------------------------------------
# WalletData.css
# ------------------------------------------------------------
write(
    "Frontend/src/components/Wallet/WalletData.css",
    """/* WALLET DATA — TERMINAL WITH NO PARENT CONSTRAINTS */

.wallet-data-root {
  height: auto !important;
  min-height: 0 !important;
  max-height: none !important;
}

/* Floating mode may scroll internally ONLY */
.wallet-data-root.floating {
  overflow: visible;
}

.wallet-data-table {
  max-height: none !important;
}
"""
)


# ------------------------------------------------------------
# WalletBackground.css
# ------------------------------------------------------------
write(
    "Frontend/src/components/Wallet/WalletBackground.css",
    """/* WALLET BACKGROUND — DECORATIVE ONLY */

.wallet-background {
  height: auto !important;
  min-height: 0 !important;
  max-height: none !important;
}
"""
)


print(f"[BULK] Completed — {files_written} file(s) updated")
