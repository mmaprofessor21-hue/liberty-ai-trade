import sys
sys.dont_write_bytecode = True

from pathlib import Path

# NOTE:
# - Keep ALL prints ASCII-only (no emojis) to avoid cp1252 UnicodeEncodeError on Windows terminals.
# - Write files as UTF-8.
# - This bulk only writes the wallet CSS files exactly as provided.

WALLET_ROOT_CSS = r"""/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER RULES
   ✅ WALLET ROOT — UNCONSTRAINED VERTICAL FLOW
*/

.wallet-root {
  position: relative;
  width: 100%;

  /* BACKGROUND ONLY — MUST GROW WITH CONTENT */
  background-repeat: no-repeat;
  background-position: center top;
  background-size: cover;

  /* 🚫 NO VERTICAL ENVELOPE */
  padding-top: 0 !important;
  padding-bottom: 0 !important;

  /* ✅ WALLET SECTION SIDE GUTTER — KEEP CONSISTENT WITH OTHER SECTIONS */
  padding-left: 48px;
  padding-right: 48px;

  overflow: visible !important;
}

/* ✅ INTERNAL WALLET SECTION WRAPPER — MUST NOT CLIP */
.wallet-section {
  position: relative;
  width: 100%;
  box-sizing: border-box;
  overflow: visible !important;
}
"""

WALLET_BACKGROUND_CSS = r"""/* ✅ BACKGROUND IS SEPARATE SO IT NEVER GETS LOST
   DO NOT ADD HEIGHT LIMITS HERE
*/

.wallet-background {
  background-image: url("../../assets/Main_Liberty_background.png");
  background-repeat: no-repeat;
  background-position: center top;
  background-size: cover;
}
"""

WALLET_CONTROLS_CSS = r"""/* ✅ WALLET CONTROLS BASE STYLING
   DO NOT ADD VERTICAL LIMITS / HEIGHT CAPS
*/

.wallet-btn {
  background: rgba(5, 18, 35, 0.72);
  border: 1px solid rgba(0, 170, 255, 0.35);
  border-radius: 12px;
  padding: 10px 22px;
  color: #ffffff;
  font-weight: 700;
  letter-spacing: 0.8px;
  cursor: pointer;
  transition: all 0.18s ease-in-out;
}

.wallet-btn:hover {
  box-shadow: 0 0 14px rgba(0, 180, 255, 0.35);
}

.wallet-btn[data-intent="positive"] {
  border-color: rgba(0, 255, 170, 0.55);
  box-shadow: 0 0 18px rgba(0, 255, 170, 0.22);
}

.wallet-btn[data-intent="neutral"] {
  border-color: rgba(0, 170, 255, 0.35);
}

.wallet-btn[data-intent="negative"] {
  border-color: rgba(255, 85, 85, 0.35);
}
"""

WALLET_DATA_CSS = r"""/* ✅ WALLET DATA (HOLDINGS / HISTORY) TERMINAL
   DO NOT ADD HEIGHT LIMITS — TERMINAL NEEDS ROOM FOR DOCK/UNDOCK
*/

.wallet-data-terminal {
  width: 100%;
  box-sizing: border-box;
}

.wallet-tabs {
  display: flex;
  gap: 8px;
  margin-top: 6px;
}

.wallet-terminal {
  margin-top: 10px;
  padding: 10px 0 0 0;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  font-size: 12px;
  white-space: pre;
  overflow: visible;
}

.wallet-data-row {
  display: grid;
  grid-template-columns: 1.2fr 1fr 0.7fr 1fr 0.7fr 0.7fr;
  gap: 16px;
  padding: 6px 0;
}

.wallet-data-row.header {
  font-weight: bold;
}

.wallet-data-footer {
  margin-top: 12px;
  text-align: right;
}
"""

def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")

def main() -> int:
    updates_root = Path(__file__).resolve().parent

    targets = [
        ("Frontend/src/components/Wallet/WalletRoot.css", WALLET_ROOT_CSS),
        ("Frontend/src/components/Wallet/WalletBackground.css", WALLET_BACKGROUND_CSS),
        ("Frontend/src/components/Wallet/WalletControls.css", WALLET_CONTROLS_CSS),
        ("Frontend/src/components/Wallet/WalletData.css", WALLET_DATA_CSS),
    ]

    wrote = 0
    for rel, text in targets:
        dest = updates_root / Path(rel)
        _write_text(dest, text)
        print(f"[BULK] {rel}")
        wrote += 1

    print(f"[BULK] Completed - {wrote} file(s) added/updated")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
