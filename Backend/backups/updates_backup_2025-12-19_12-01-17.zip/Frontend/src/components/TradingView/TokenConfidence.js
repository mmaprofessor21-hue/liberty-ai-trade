
import React from "react";
import "./TokenConfidence.css";

/**
 * Small UI element to show detection confidence.
 * Useful for debugging and validation during development.
 */

export default function TokenConfidence({ token, confidence }) {
    return (
        <div className="token-confidence-box">
            <div className="token-confidence-label">
                Token: {token ?? "N/A"}
            </div>
            <div className="token-confidence-score">
                Confidence: {confidence ?? 0}%
            </div>
        </div>
    );
}
