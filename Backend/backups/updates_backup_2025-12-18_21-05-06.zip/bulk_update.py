#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE_DIR = os.path.dirname(__file__)
files_written = 0

def write(path, content):
    global files_written
    full_path = os.path.join(BASE_DIR, path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK] {path}")
    files_written += 1


# ============================================================
# WALLET ROOT — VERTICAL ELASTICITY FIX
# ------------------------------------------------------------
# PURPOSE:
# - Remove vertical constraint caused by hard padding
# - Allow Wallet Data to define its own height
# - Preserve background + visuals
#
# SCOPE:
# - WALLET ROOT ONLY
# - No child modifications
# ============================================================

write(
    "Frontend/src/components/Wallet/WalletRoot.css",
    """/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
   ✅ WALLET ROOT — ENABLE VERTICAL ELASTICITY
   ✅ PRESERVES ALL EXISTING VISUALS
*/

/* BEFORE:
   padding-top: 72px;
   padding-bottom: 72px;
   (This created a hard vertical envelope)
*/

.wallet-root {
  padding-top: 0 !important;
  padding-bottom: 0 !important;
}

/* Maintain visual spacing at section level instead */
.wallet-section:first-of-type {
  margin-top: 72px;
}

.wallet-section:last-of-type {
  margin-bottom: 72px;
}
"""
)

print(f"[BULK] Completed — {files_written} file(s) updated")
