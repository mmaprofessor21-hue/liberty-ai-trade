console.log("TradingViewPanel docked height constraint removed (test)");
