print("TradingViewPanel docked height constraint removed (backend test)")
