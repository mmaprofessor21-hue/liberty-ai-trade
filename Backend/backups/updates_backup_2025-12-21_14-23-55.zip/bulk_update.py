#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

# ---------------------------------------------------------
# README COMPLIANCE:
# - WRITE ONLY inside update_engine/updates/ (drop zone)
# - NO live folder writes
# - PRINT [BULK] line per written file
# - PRINT final success line with exact count
# - UTF-8 writes only
# - NO timestamps (core injects)
# - NO updater_core imports
# ---------------------------------------------------------

DROP_ZONE_DIR = os.path.dirname(os.path.abspath(__file__))

def _write(rel_path, content):
    abs_path = os.path.join(DROP_ZONE_DIR, rel_path.replace("/", os.sep))
    os.makedirs(os.path.dirname(abs_path), exist_ok=True)
    with open(abs_path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {rel_path}")

def main():
    written = 0

    # ---------------------------------------------------------
    # TradingViewChartSection.css
    # Scoped contract override to escape ancestor height clamps
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/TradingView/TradingViewChartSection.css",
        """\
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */

/* =========================================================
   TradingView Container Contract Override (LOCKED)
   Purpose:
   - Allow organic vertical growth
   - Escape ancestor height clamps (e.g., layout engines)
   - Preserve TradingView autosize behavior
   ========================================================= */

.tradingview-section,
.tradingview-chart-section {
  position: relative !important;

  /* Organic flow */
  height: auto !important;
  min-height: 520px;
  max-height: none !important;

  display: flex;
  flex-direction: column;
  flex-grow: 1;

  overflow: visible !important;
}
"""
    )
    written += 1

    # ---------------------------------------------------------
    # ChartContainer.css
    # Ensure container + iframe can stretch vertically
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/TradingView/ChartContainer.css",
        """\
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */

/* =========================================================
   TradingView Chart Container Override (LOCKED)
   Purpose:
   - Prevent vertical compression
   - Allow iframe to fill container height
   - Keep TradingView autosize authoritative
   ========================================================= */

.tradingview-chart-container {
  width: 100%;
  position: relative !important;

  /* Organic height */
  height: auto !important;
  min-height: 480px;
  max-height: none !important;

  display: flex;
  flex-direction: column;
  flex-grow: 1;

  overflow: hidden;
}

/* Make sure any inner wrappers can stretch */
.tradingview-chart-container > div {
  flex-grow: 1;
  display: flex;
  flex-direction: column;
  min-height: 480px;
}

/* Ensure iframe fills available height */
.tradingview-chart-container iframe {
  width: 100% !important;
  height: 100% !important;
  min-height: 480px;
  border: 0;
  display: block;
}
"""
    )
    written += 1

    # ---------------------------------------------------------
    # TradingViewPanel.css
    # Docked must be organic; floating can stay constrained
    # Also ensure panel can grow inside flex contexts
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/TradingView/TradingViewPanel.css",
        """\
/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* 🚫 NO IMPORT OVERRIDES | 🚫 NO PATH ASSUMPTIONS | ✅ ABSOLUTE STRUCTURE COMPLIANCE */

/* =========================================================
   TradingView Panel — Height Contract (LOCKED)
   - Docked: ORGANIC HEIGHT (NO CAPS)
   - Floating: CONTROLLED HEIGHT ALLOWED
   - Panel must be allowed to grow in flex layouts
   ========================================================= */

.tv-container {
  position: relative;
  width: 100%;
  overflow: visible;

  /* Allow growth inside flex parents */
  height: auto !important;
  min-height: 520px;
  max-height: none !important;

  display: flex;
  flex-direction: column;
  flex-grow: 1;
}

/* -----------------------------
   DOCKED MODE (PAGE FLOW)
   ----------------------------- */
.tv-container.docked {
  position: relative;
  width: 100%;

  /* CRITICAL: NO HEIGHT CAPS */
  height: auto !important;
  min-height: 520px;
  max-height: none !important;

  margin-top: 15px;
  overflow: visible !important;

  display: flex;
  flex-direction: column;
  flex-grow: 1;
}

/* -----------------------------
   FLOATING MODE (WINDOW-LIKE)
   ----------------------------- */
.tv-container.floating {
  position: fixed;
  width: 80%;
  height: 70vh;          /* Intentional: floating may be constrained */
  min-height: 480px;
  max-height: 90vh;

  top: 10%;
  left: 10%;
  z-index: 1000;
  overflow: hidden;

  display: flex;
  flex-direction: column;
}

/* Ensure chart container can stretch inside tv-container */
.tv-container .tradingview-chart-container {
  flex-grow: 1;
  min-height: 480px;
}
"""
    )
    written += 1

    # ---------------------------------------------------------
    # MANDATORY UPDATER TEST FILES (ALWAYS UPDATED)
    # ---------------------------------------------------------
    _write(
        "Frontend/src/components/tests/test_update.js",
        """\
console.log("Updater mandatory test_update.js executed (TradingView contract bulk)");
"""
    )
    written += 1

    _write(
        "Backend/tests/test_update.py",
        """\
print("Updater mandatory test_update.py executed (TradingView contract bulk)")
"""
    )
    written += 1

    print(f"[BULK] Successfully processed {written} files")

if __name__ == "__main__":
    main()
