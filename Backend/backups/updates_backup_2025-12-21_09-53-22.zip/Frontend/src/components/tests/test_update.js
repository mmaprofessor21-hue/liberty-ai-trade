export default () => 'frontend import rewire test';
