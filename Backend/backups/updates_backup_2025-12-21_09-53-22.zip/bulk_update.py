import sys
sys.dont_write_bytecode = True

import os
from pathlib import Path

print("[BULK] Phase O-2 — Indicators import verification START")

PROJECT_ROOT = Path.cwd()
FRONTEND = PROJECT_ROOT / "Frontend" / "src" / "components" / "TradingView"

INDICATOR_FILES = [
    FRONTEND / "overlays" / "indicators" / "StrategyIndicator.js",
    FRONTEND / "overlays" / "indicators" / "TradingViewMarkers.js",
]

def safe_verify_imports(file_path: Path):
    if not file_path.exists():
        print(f"[BULK] SKIPPED (not found): {file_path.relative_to(PROJECT_ROOT)}")
        return

    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception as e:
        print(f"[BULK][ERROR] Failed reading {file_path.name}: {e}")
        return

    updated = False
    lines = content.splitlines()

    rewritten = []
    for line in lines:
        original = line

        # Normalize legacy relative imports (SAFE ONLY)
        if "../StrategyIndicator" in line:
            line = line.replace("../StrategyIndicator", "./StrategyIndicator")
        if "../TradingViewMarkers" in line:
            line = line.replace("../TradingViewMarkers", "./TradingViewMarkers")

        if line != original:
            updated = True

        rewritten.append(line)

    if updated:
        file_path.write_text("\n".join(rewritten) + "\n", encoding="utf-8")
        print(f"[BULK] UPDATED IMPORTS: {file_path.relative_to(PROJECT_ROOT)}")
    else:
        print(f"[BULK] NO CHANGE: {file_path.relative_to(PROJECT_ROOT)}")

# --- Execute verification ---
for indicator in INDICATOR_FILES:
    safe_verify_imports(indicator)

# --- REQUIRED TEST FILE TOUCH (per README) ---
frontend_test = PROJECT_ROOT / "Frontend" / "src" / "components" / "tests" / "test_update.js"
backend_test = PROJECT_ROOT / "Backend" / "tests" / "test_update.py"

if frontend_test.exists():
    frontend_test.write_text(
        frontend_test.read_text(encoding="utf-8") + "\n// Phase O-2 indicator verification\n",
        encoding="utf-8",
    )
    print("[BULK] UPDATED TEST FILE:", frontend_test.relative_to(PROJECT_ROOT))

if backend_test.exists():
    backend_test.write_text(
        backend_test.read_text(encoding="utf-8") + "\n# Phase O-2 indicator verification\n",
        encoding="utf-8",
    )
    print("[BULK] UPDATED TEST FILE:", backend_test.relative_to(PROJECT_ROOT))

print("[BULK] Phase O-2 — Indicators import verification COMPLETE")
