#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE = os.path.dirname(__file__)

FILES = {}

def write(path, content):
    full = os.path.join(BASE, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"[BULK]   {path}")
    FILES[path] = True


# -------------------------------------------------
# TradingViewController.js
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewController.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useEffect, useRef, useState } from "react";
import ChartContainer from "./ChartContainer";
import TradingViewWidget from "./TradingViewWidget";
import TradingViewDock from "./TradingViewDock";

export default function TradingViewController() {
  const containerRef = useRef(null);
  const widgetRef = useRef(null);
  const [symbol, setSymbol] = useState("BINANCE:BTCUSDT");

  useEffect(() => {
    if (!containerRef.current) return;

    if (widgetRef.current) {
      widgetRef.current.remove();
      widgetRef.current = null;
    }

    widgetRef.current = TradingViewWidget({
      container: containerRef.current,
      symbol,
    });

    return () => {
      if (widgetRef.current) {
        widgetRef.current.remove();
        widgetRef.current = null;
      }
    };
  }, [symbol]);

  return (
    <TradingViewDock>
      <div className="tradingview-search">
        <input
          type="text"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          placeholder="EXCHANGE:SYMBOL"
        />
      </div>

      <ChartContainer containerRef={containerRef} />
    </TradingViewDock>
  );
}
"""
)


# -------------------------------------------------
# TradingViewWidget.js
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewWidget.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

export default function TradingViewWidget({ container, symbol }) {
  if (!window.TradingView) return null;

  const widget = new window.TradingView.widget({
    container_id: container,
    autosize: true,
    symbol: symbol,
    interval: "15",
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    enable_publishing: false,
    hide_top_toolbar: false,
    hide_legend: false,
    save_image: false,
  });

  return widget;
}
"""
)


# -------------------------------------------------
# ChartContainer.js
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/ChartContainer.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React from "react";
import "./ChartContainer.css";

export default function ChartContainer({ containerRef }) {
  return (
    <div className="chart-container">
      <div ref={containerRef} className="chart-inner" />
    </div>
  );
}
"""
)


# -------------------------------------------------
# ChartContainer.css
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/ChartContainer.css",
    """/* DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt */
/* NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE */

.chart-container {
  width: 100%;
  height: 100%;
  position: relative;
}

.chart-inner {
  width: 100%;
  height: 100%;
}
"""
)


# -------------------------------------------------
# TradingViewDock.js
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewDock.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React, { useRef } from "react";
import "./TradingViewDock.css";

export default function TradingViewDock({ children }) {
  const ref = useRef(null);

  return (
    <div className="tradingview-dock" ref={ref}>
      {children}
    </div>
  );
}
"""
)


# -------------------------------------------------
# TradingViewFloating.js
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/TradingViewFloating.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

import React from "react";
import "./TradingViewFloating.css";

export default function TradingViewFloating({ children }) {
  return <div className="tradingview-floating">{children}</div>;
}
"""
)


# -------------------------------------------------
# DockManager.js
# -------------------------------------------------
write(
    "Frontend/src/components/TradingView/DockManager.js",
    """// DO NOT MODIFY THIS FILE OUTSIDE THE RULES IN README_UPDATER.txt
// NO IMPORT OVERRIDES | NO PATH ASSUMPTIONS | ABSOLUTE STRUCTURE COMPLIANCE

export function enableDrag(element) {
  if (!element) return;

  let isDragging = false;
  let startX = 0;
  let startY = 0;

  element.addEventListener("mousedown", (e) => {
    isDragging = true;
    startX = e.clientX - element.offsetLeft;
    startY = e.clientY - element.offsetTop;
  });

  document.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    element.style.left = e.clientX - startX + "px";
    element.style.top = e.clientY - startY + "px";
  });

  document.addEventListener("mouseup", () => {
    isDragging = false;
  });
}
"""
)


# -------------------------------------------------
# MANDATORY TEST FILES
# -------------------------------------------------
write(
    "Frontend/src/components/tests/test_update.js",
    """// updater test file
export const UPDATE_TEST = "TradingView Feature Phase";
"""
)

write(
    "Backend/tests/test_update.py",
    "# updater test file\nUPDATE_TEST = 'TradingView Feature Phase'\n"
)


print(f"[BULK] Successfully processed {len(FILES)} files")
