
import React, { useEffect } from "react";
import { resolveToken } from "./TokenRouter";

export default function TokenWatcher({ onResolve }) {

    useEffect(() => {

        const collectCandidates = () => {
            try {
                const nodes = Array.from(document.querySelectorAll("span, div"))
                    .map(el => el.textContent)
                    .filter(t => t && /^[A-Z:0-9\.\-\/]{3,20}$/.test(t));

                const structured = nodes.map(n => ({
                    raw: n.trim(),
                    type: "mutation"
                }));

                const result = resolveToken(structured);
                if (result && result.token) onResolve(result);

            } catch (err) {
                console.warn("TokenWatcher error:", err);
            }
        };

        const observer = new MutationObserver(() => {
            collectCandidates();
        });

        const root = document.querySelector("#root");
        if (root) observer.observe(root, { childList: true, subtree: true });

        const fallback = setInterval(collectCandidates, 2000);

        collectCandidates();

        return () => {
            observer.disconnect();
            clearInterval(fallback);
        };

    }, [onResolve]);

    return null;
}
