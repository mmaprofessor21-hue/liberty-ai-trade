#!/usr/bin/env python3
import sys
sys.dont_write_bytecode = True

import os

BASE_DIR = os.path.dirname(__file__)
count = 0

def write(rel_path: str, content: str) -> None:
    global count
    full_path = os.path.join(BASE_DIR, rel_path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(content)
    print("[BULK] " + rel_path)
    count += 1


# ============================================================
# WALLET — BACKGROUND RESTORE ONLY
# - No container changes in this pass (beyond existing file contents)
# - No behavior changes
# - Restores Main_Liberty_background.png on wallet-root
# ============================================================

write(
    "Frontend/src/components/Wallet/WalletRoot.css",
    """/* 🚨 DO NOT MODIFY THIS FILE OUTSIDE README_UPDATER RULES
   ✅ WALLET ROOT — UNCONSTRAINED VERTICAL FLOW
*/

.wallet-root {
  position: relative;
  width: 100%;

  /* BACKGROUND ONLY — MUST GROW WITH CONTENT */
  background-image: url("../../assets/Main_Liberty_background.png");
  background-repeat: no-repeat;
  background-position: center top;
  background-size: cover;

  /* 🚫 NO VERTICAL ENVELOPE */
  padding-top: 0 !important;
  padding-bottom: 0 !important;

  height: auto !important;
  min-height: 0 !important;
  max-height: none !important;

  overflow: visible;
}

/* Section spacing is decorative only */
.wallet-section {
  height: auto !important;
  min-height: 0 !important;
  max-height: none !important;
}
"""
)

print(f"[BULK] Completed - {count} file(s) updated")
